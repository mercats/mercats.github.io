<?php
        session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercados BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_qui_som.css">
</head>
<body>
    <header>
        <header>
            <?php
                if(isset($_SESSION['id_usuario'])){
                    include_once("php_navbars_qui_som/qui_som_login_es.php");
                }
                else{
                    include_once("php_navbars_qui_som/qui_som_no_login_es.php");
                }
            ?>
        </header>
    
        <main>
            <div class="us_div us_div1 col-md-6 w3-animate-opacity">
                <div class="us_explanation">
                    <p>
                        CEPSoft Consulting es una empresa joven ubicada en el centro de Barcelona. Nos dedicamos al desarrollo de soluciones web mediante la creación de proyectos personalizados y adaptados a las necesidades de nuestros clientes.
                        Actualmente contamos con una plantilla de 4 creadores informáticos que quieren brindar soluciones innovadoras y atractivas a nuestros clientes. Nuestro equipo es muy joven y dinámico, con muchas ganas de afrontar los retos que se nos presenten con imaginación, ilusión e implicación.
                        <br/><br/>Una vez que aceptamos un desafío queremos encontrar la mejor solución, para nosotros esto significa:
                        <br/><strong>Resolver el problema.</strong>
                        <br/><strong>Dar la mejor solución técnica.</strong>
                        <br/><strong>Proporcionar una solución útil, fácil de usar, elegante, creativa, diferente e impactante. Queremos facilitarle las cosas al departamento de marketing.</strong>
                        <br/>cepsoft@cep.net
                    </p>
                </div>
            </div>

            <div class="container d-flex justify-content-center col-md-6 us">
                <div class="row">
                    <div class="col-md-6 w3-animate-left pers">
                        <div class="card p-3 py-1 mt-3 ampliar">
                            <div class="text-center"><img src="images/roger.png" width="100px" height="120px" class="rounded-circle pics"></a>
                                <input type="checkbox" id="personal1"></input>
                                <label for="personal1">Roger Comorera <br/>Agustí</label> 
                                <div class="personal"><h2 class="desc">Tengo 28 años, soy una persona algo reservada, de caracter serio. Me gustan los animales, apasionado de la música y me atraen los juegos, tanto de mesa como de ordenador.
                                    Hace poco descubrí mi interés por la informática y actualmente me encuentro trabajando y estudiando para poder dar un cambio a mi vida profesional para poder dedicarme a este nuevo mundo que día a día me ofrece nuevas oportunidades.</h2></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-right pers">
                        <div class="card p-3 py-1 mt-3 ampliar">
                            <div class="text-center"> <img src="images/arnau.png" width="100px" height="120px" class="rounded-circle pics">
                                <input type="checkbox" id="personal2"></input>
                                <label for="personal2">Arnau Bayó<br/>García</label>
                                <div class="personal"><h2 class="desc">Tengo 21 años, soy una persona algo tímida, gran amante del deporte físico y de los deportes de contacto. Estoy estudiando programación dado que es un campo que me resulta muy interesante y ofrece muchas posibilidades laborales.</h2></div>
                            </div> 
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-left pers">
                        <div class="card p-3 py-1 mt-5 ampliar">
                            <div class="text-center"> <img src="images/dani.png" width="100px" height="120px" class="rounded-circle pics">
                                <input type="checkbox" id="personal3"></input>
                                <label for="personal3">Daniel Fernández<br/>Jiménez</label>
                                <div class="personal"><h2 class="desc">Tengo 22 años, me defino como una persona extrovertida, carismática y alegre. Me gusta superar mis expectativas cada día y pasar tiempo con la gente de mi alrededor, pero también tengo momentos en los que prefiero estar un poco mas relajado.
                                    Mi interés por la informática nació gracias a los videojuegos, y cada vez me veo más cerca de mi objetivo.
                                </h2></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-right pers">
                        <div class="card p-3 py-1 mt-5 ampliar">
                            <div class="text-center"><img src="images/oscar.png" width="100px" height="120px" class="rounded-circle pics"></a>
                                <input type="checkbox" id="personal4"></input>
                                <label for="personal4">Óscar González <br/>Zarrias</label>
                                <div class="personal"><h2 class="desc">Tengo 22 años, soy introvertido, curioso e independiente. Me encanta ir al cine y escuchar heavy metal mientras paseo o recorro el mundo con mis patines en línea. Me interesa la programación por la infinidad de posibilidades que ofrece al alcance de todos, espero trabajar en ello y hacer grandes cosas.</h2></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </main>
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>