<?php
 session_start(); 
  require_once('./php_librarys/bd.php');
  $mercados = selectMercados();
  $usuario_has_mercados = selectUsuarioHasMercados();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercats BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_ofertes.css">
    <script src="https://kit.fontawesome.com/cb62354e55.js" crossorigin="anonymous"></script>
</head>
<body>
        <form action="./php_controllers/proyecto_control.php" method="POST" enctype="multipart/form-data">
            <div class="mercats_body">
                <div class="mercats_body2">
                    <header>
                    <?php
                            if(isset($_SESSION['id_usuario'])){
                                include_once("php_navbars_ofertes/ofertes_login.php");
                            }
                            else{
                                include_once("php_navbars_ofertes/ofertes_no_login.php");
                            }         
                    ?>
                    </header>
                
                    <main>
                    <div class="mercats_div mercats_div1 col-md-6 w3-animate-opacity">
                    <?php include_once('php_partials/mensaje.php');
                    if(isset($_SESSION['nombreMercado'])){?>
                        <h3 class="h1_mercats w3-animate-opacity" style="color: #FFFFFF; text-align: center; text-shadow: 2px 2px black; background: rgba(0, 0, 0, 0.5); padding-bottom:5px;"><?php echo $_SESSION['nombreMercado']?></h3>
                        <?php unset($_SESSION['nombreMercado']);
                    }?>
                        
                            <table class = "table">
                                <tr>
                                    <td>Tipus de comerci</td>
                                    <td>Punts</td>
                                    <td>Descripció</td>
                                </tr>
                                    <?php 
                                    if(isset($_SESSION['ofertasMercado'])) {
                                        foreach($_SESSION['ofertasMercado'] as $oferta){?>
                                            <tr>
                                                <td><?php echo $oferta['tipo_negocio']?></td>
                                                <td><?php echo $oferta['coste_puntos']?></td>
                                                <td><?php echo $oferta['descripcion']?></td>
                                                <?php if(isset($_SESSION['id_usuario'])) { ?>
                                                    <td> <button type="button" class="btn btn-primary" data-id="<?php echo $oferta['id_oferta']?>" data-toggle="modal" data-target="#modalFunction"><i class="fas fa-cart-plus fa-2x"></i></button> </td>
                                                <?php } ?>
                                            </tr>
                                        <?php }
                                        unset($_SESSION['ofertasMercado']);
                                     } ?>
                            </table> 
                        
                            
                    </div>
                    <input type="hidden" name ="lang" value="ofertas_cat">
                    <?php
                        if(isset($_SESSION['id_usuario']) && $_SESSION["mostrarTodosLosMercados"] == false){?>
                            <div class="mercats_div col-md-6 mercats_div2"> 
                                <br><br>
                                <button type="submit" name="tipoMercado" value = 1 class="btn btn-outline-dark"><h3 class="h1_mercats w3-animate-opacity">Mercats Alimentaris</h3></button>
                                <br><br>
                                <button type="submit" name="tipoMercado" value = 0 class="btn btn-outline-dark"><h3 class="h1_mercats w3-animate-opacity">Mercats no Alimentaris</h3></button>
                                <br><br>

                                <?php if(isset($_SESSION['tipoMercado'])){
                                        if($_SESSION['tipoMercado'] == 1){?>
                                            <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Mercats Alimentaris</h3>
                                        <?php }else if($_SESSION['tipoMercado'] == 0){?>
                                            <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Mercats no Alimentaris</h3>
                                    <?php } 
                                }else{?>
                                    <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Seleccioni un tipus de mercat</h3>
                                <?php }?>

                                <br><br><br>
                                
                                <?php if(isset($_SESSION['tipoMercado'])){ ?>
                                <select name="opcionMercado" class="form-select" aria-label="Default select example">
                                    <option disabled selected>Seleccioni un mercat</option>
                                    <?php foreach($mercados as $mercado){
                                        if($_SESSION['tipoMercado'] == $mercado['mercado_alimentario'] ){
                                            foreach($usuario_has_mercados as $usuario_has_mercado){
                                                if($usuario_has_mercado['id_mercado'] == $mercado['id_mercado']){
                                                    if($usuario_has_mercado['id_usuario'] == $_SESSION['id_usuario']){?>
                                                        <option  value=<?php echo $mercado['id_mercado']?> ><?php echo $mercado['nombre']?> </option>
                                                    <?php }
                                                }
                                            }      
                                        }
                                    }?>
                                </select>
                                <?php } 
                                else{?>
                                    <select name="opcionMercado" class="form-select" aria-label="Default select example" disabled>
                                        <option disabled selected>Seleccioni un mercat</option>
                                    </select>
                                <?php }?>

                                <br><br><br>
                                <?php if(isset($_SESSION['tipoMercado'])){ ?>
                                    <button type="submit" name="buscarOfertas" class="btn btn-outline-dark">Cercar</button>
                                <?php } 
                                else{?>
                                     <button type="submit" name="buscarOfertas" class="btn btn-outline-dark" disabled>Cercar</button>
                                     <?php }?>                   
                                    <button type="submit" name="MostrarTodosLosMercados" class="btn btn-outline-dark botonMercados" style="width: 150px; float: right; margin-top:20px;">Mostrar tots els mercats</button>
                            </div> 
                        <?php }
                        else{?>
                            <div class="mercats_div col-md-6 mercats_div2"> 
                                <br><br>
                                <button type="submit" name="tipoMercado" value = 1 class="btn btn-outline-dark"><h3 class="h1_mercats w3-animate-opacity">Mercats Alimentaris</h3></button>
                                <br><br>
                                <button type="submit" name="tipoMercado" value = 0 class="btn btn-outline-dark"><h3 class="h1_mercats w3-animate-opacity">Mercats no Alimentaris</h3></button>
                                <br><br>
                                <?php if(isset($_SESSION['tipoMercado'])){
                                        if($_SESSION['tipoMercado'] == 1){?>
                                            <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Mercats Alimentaris</h3>
                                        <?php }else if($_SESSION['tipoMercado'] == 0){?>
                                            <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Mercats no Alimentaris</h3>
                                    <?php } 
                                }else{?>
                                    <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Seleccioni un tipus de mercat</h3>
                                <?php }?>

                                <br><br><br>
                                <?php if(isset($_SESSION['tipoMercado'])){ ?>
                                <select name="opcionMercado" class="form-select" aria-label="Default select example">
                                    <option disabled selected>Seleccioni un mercat</option>
                                    <?php foreach($mercados as $mercado){
                                        if($_SESSION['tipoMercado'] == $mercado['mercado_alimentario'] ){?>
                                        <option value=<?php echo $mercado['id_mercado']?> ><?php echo $mercado['nombre']?> </option>
                                    <?php }
                                    }?>
                                </select>
                                <?php } 
                                else{?>
                                    <select name="opcionMercado" class="form-select" aria-label="Default select example" disabled>
                                        <option disabled selected>Seleccioni un mercat</option>
                                    </select>
                                <?php }?>
                                <br><br><br>
                                <?php if(isset($_SESSION['tipoMercado'])){ ?>
                                    <button type="submit" name="buscarOfertas" class="btn btn-outline-dark">Cercar</button>
                                <?php } 
                                else{?>
                                     <button type="submit" name="buscarOfertas" class="btn btn-outline-dark" disabled>Cercar</button>
                                     <?php }
                                    if(isset($_SESSION["id_usuario"])){?>
                                        <button type="submit" name="MostrarTusMercados" class="btn btn-outline-dark botonMercados" style="width: 150px; float: right; margin-top:20px;">Mostrar els teus mercats</button>
                                    <?php }?>
                            </div>   
                        <?php }?> 
                    </main>
                </div>
            </div> 
        </form>                    
</body>
<div class="modal fade" id="modalFunction" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="./php_controllers/proyecto_control.php" method="POST" enctype="multipart/form-data">
            <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="staticBackdropLabel" style= "text-align: center;">Bescanviar oferta</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Segur que voleu bescanviar aquesta oferta?
                Una vegada fet, no es podrà retornar.
                <input type="hidden" name ="lang" value="ofertas_cat">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                
                    <button href="#" class="btn btn-outline-primary" type= "submit" name="canjearOferta"> Sí </button>
                    <input type="hidden" class="form-control" id="inputIdOferta" name="inputIdOferta">
            </div>
            </div>
        </form>
    </div>
</div>

<script>
    $('#modalFunction').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('id') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-footer #inputIdOferta').val(recipient)
})

</script>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>