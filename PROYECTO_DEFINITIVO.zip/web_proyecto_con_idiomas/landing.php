
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercats BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_landing.css">
    <script src="./js_landing.js"></script> 
</head>
<body>
    <div class="main_landing">
        
        <header>
           
        </header>

        <main>

            <div id="div1" class="row col-md-6 div_huge div1 w3-animate-opacity">
                <h1 class="main_title w3-animate-left">MERCATS DE BARCELONA</h1>
                <div id="idiomas">
                    <a href="./landing_es.php" class="idioma primeridioma">
                        <img src="./images/castella.png" width="100" height="50" alt="Spanish">   
                    </a>
                    <a href="./landing_en.php" class="idioma segundoidioma">
                        <img src="./images/angles.png" width="100" height="50" alt="Inglés">  
                    </a>
                </div>
            </div>

            <div class="col-md-6 div_huge div2 w3-animate-top">
                <div class="row col-md-8 main_1 ">
                    
                    <h1>Tots sumem!</h1>
                    <p>Una iniciativa orientada a promocionar, dinamitzar i ajudar als comerços locals.</p>
                </div>

                <div class="main_2">
                    <a href="./main.php">
                        <h1>Entrar</h1>
                    </a>
                </div>
                
            </div>

           
           

        </main>
    
        </footer>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>