
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark main_navbar" style="border-bottom: solid 2px #2196f3">
            <a class="navbar-brand" href="main_en.php">Barcelona Markets</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div id="idiomas" style="margin-left: 30%;">
                <div  class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                    <a href="ofertes.php" id="primeridioma">
                        <img src="./images/catala.png" width="40" height="20" alt="Catalan">   
                    </a>
                    <a href="ofertes_es.php">
                        <img src="./images/castella.png" width="40" height="20" alt="Spanish">  
                    </a>
                </div>
            </div>
            <div class="buttons_nav" style="position: absolute; display: flex; margin-left: 55%;">
                <div class="button_ofertes" style="margin-right: 15%;">
                    <a href="./ofertes_en.php">
                        <img src="./images/Offers_button.png" width="30" height="30" style="border-radius: 50%;">
                    </a>
                </div>

                <div class="button_jocs" style="margin-right: 15%;">
                    <a href="./jocs_en.php">
                        <img src="./images/Game_button.png" width="30" height="30" style="border-radius: 50%;">
                    </a>
                </div>

                <div class="button_mercats" style="margin-right: 15%;">
                    <a href="./mercats_bcn_en.php">
                        <img src="./images/Market_button.png" width="30" height="30" style="border-radius: 50%;">
                    </a>
                </div>

                <div class="button_qui_som">
                    <a href="./qui_som_en.php">
                        <img src="./images/People_button.png" width="30" height="30" style="border-radius: 50%;">
                    </a>
                </div>

            </div>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            User
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="left:-70px">
                            <a class="dropdown-item" href="usuari_en.php">Log in</a>
                            <a class="dropdown-item" href="registre_en.php">Sign in</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
</html>