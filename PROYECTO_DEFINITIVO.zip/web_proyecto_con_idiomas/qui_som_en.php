<?php
        session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BCN Markets</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_qui_som.css">
</head>
<body>
    <header>
        <header>
            <?php
                if(isset($_SESSION['id_usuario'])){
                    include_once("php_navbars_qui_som/qui_som_login_en.php");
                }
                else{
                    include_once("php_navbars_qui_som/qui_som_no_login_en.php");
                }
            ?>
        </header>
    
        <main>
            <div class="us_div us_div1 col-md-6 w3-animate-opacity">
                <div class="us_explanation">
                    <p>
                        CEPSoft Consulting is a young company located in the center of Barcelona. We are dedicated to the development of web solutions by creating customized projects and tailored to the needs of our customers.
                        We currently have a staff of 4 computer creators who want to provide innovative and attractive solutions to our clients. Our team is very young and dynamic, eager to face the challenges that are presented to us with imagination, enthusiasm and involvement. 
                        <br/><br/>Once we accept a challenge we want to find the best solution, for us this means:
                        <br/><strong>Solve the problem.</strong>
                        <br/><strong>Give the best technical solution.</strong>
                        <br/><strong>Provide a useful, user-friendly, elegant, creative, different and impactful solution. We want to make things easy for the marketing department.</strong>
                        <br/>cepsoft@cep.net
                    </p>

                </div>
            </div>

            <div class="container d-flex justify-content-center col-md-6 us">
                <div class="row">
                    <div class="col-md-6 w3-animate-left pers">
                        <div class="card p-3 py-1 mt-3 ampliar">
                            <div class="text-center"><img src="images/roger.png" width="100px" height="120px" class="rounded-circle pics"></a>
                                <input type="checkbox" id="personal1"></input>
                                <label for="personal1">Roger Comorera <br/>Agustí</label> 
                                <div class="personal"><h2 class="desc">I am 28 years old, I am a somewhat reserved person, with a serious character. I like animals, passionate about music and games attract me, both table and computer.
                                    I recently discovered my interest in computing and I am currently working and studying in order to change my professional life in order to dedicate myself to this new world that offers me new opportunities every day.</h2></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-right pers">
                        <div class="card p-3 py-1 mt-3 ampliar">
                            <div class="text-center"> <img src="images/arnau.png" width="100px" height="120px" class="rounded-circle pics">
                                <input type="checkbox" id="personal2"></input>
                                <label for="personal2">Arnau Bayó<br/>García</label>
                                <div class="personal"><h2 class="desc">I am 21 years old, I am a somewhat shy person, great lover of physical sport and contact sports. I'm studying programming because it is a field that I find very interesting and offers many job possibilities.</h2></div>
                            </div> 
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-left pers">
                        <div class="card p-3 py-1 mt-5 ampliar">
                            <div class="text-center"> <img src="images/dani.png" width="100px" height="120px" class="rounded-circle pics">
                                <input type="checkbox" id="personal3"></input>
                                <label for="personal3">Daniel Fernández<br/>Jiménez</label>
                                <div class="personal"><h2 class="desc">I am 22 years old, I define myself as an outgoing, charismatic and cheerful person. I like to exceed my expectations every day and spend time with the people around me, but I also have times when I'd rather be a little more relaxed.
                                    My interest in computing was born thanks to video games, and I'm getting closer and closer to my goal.
                                </h2></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 w3-animate-right pers">
                        <div class="card p-3 py-1 mt-5 ampliar">
                            <div class="text-center"><img src="images/oscar.png" width="100px" height="120px" class="rounded-circle pics"></a>
                                <input type="checkbox" id="personal4"></input>
                                <label for="personal4">Óscar González <br/>Zarrias</label>
                                <div class="personal"><h2 class="desc">I'm 22 years old, I'm introverted, curious and independent. I love going to the movies and listening to heavy metal while walking or touring the world with my inline skates. I am interested in programming because of the myriad possibilities it offers available to all, I hope to work on it and do great things.</h2></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
   
    <footer>
        <input type="hidden" name ="lang" value="en">
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>