<?php
        session_start();
        require_once('./php_librarys/bd.php');
        $mercados = selectMercados();
        $numMercado = 0;
        $posicioMercatLeft = false;
        $mercadoNoAlimentarioShow = false;
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mercats BCN</title>        
        <link rel="stylesheet" href="./styles/styles_propios_mercats_bcn.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>
        <div class="mercats_body">
            <div class="mercats_body2">
                <header>
                    <?php
                              if(isset($_SESSION['id_usuario'])){
                                include_once("php_navbars_mercats_bcn/mercats_bcn_login.php");
                            }
                            else{
                                include_once("php_navbars_mercats_bcn/mercats_bcn_no_login.php");
                            }
                    ?>
                </header>
            
            <main>
                <div class="mercats_div mercats_div1 col-md-6 w3-animate-opacity">
                        <p>
                            A continuació es mostra un llistat amb tots els mercats ubicats a la ciutat de Barcelona. Al fer click als enllaços, aquests et portarán a les pàgines web oficials d'aquests mercats.
                            Pels mercats que no disposen d'un web propi, es redirigirà al web de l'ajuntament de Barcelona referent al mercat en questió.
                        </br>
                            Arran de la declaració de l'estat d'alarma per evitar la propagació de la covid-19, els mercats s'han adaptat i reforçat els seus serveis de compra online i a domicili per tal de facilitar la compra des de casa a la ciutadania. Per consultar els mercats que ofereixen aquests serveis feu click al següent enllaç:
                        </p>
                        <a href="https://ajuntament.barcelona.cat/mercats/ca/canal/serveis-als-mercats">Serveis</a>
        
                </div>

                <div class="mercats_div col-md-6 mercats_div2">
                    <div class="div_list div_list_al">
                        <h1 class="h1_mercats w3-animate-opacity">Mercats Alimentaris</h1>
                              <?php foreach($mercados as $mercado){
                                if($numMercado <=19){?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php } 
                                else if($numMercado > 19 && $numMercado <= 38){?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php }   

                                else if($numMercado >= 39){
                                    if($mercadoNoAlimentarioShow == false){?>
                                        <div style="margin-top: 50%; position:absolute"><h1 class="h1_mercats w3-animate-opacity">Mercats No-Alimentaris</h1>
                                        <?php $mercadoNoAlimentarioShow = true;
                                         } ?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php }   
                               }?>
                        </div>
                    </div>
                </div>
            </main>

            <footer>
                
            </footer>
        </div>
        </div>
    </body>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>