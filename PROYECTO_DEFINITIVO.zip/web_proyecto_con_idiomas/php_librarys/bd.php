<?php
    function error($e){
        if(!empty($e->errorInfo[1])){
            switch($e->errorInfo[1]){
                case 1062:
                        if($_SESSION['ruta'] == "ofertas_cat"){
                            $mensaje = "Ja téns aquesta oferta.";
                            unset($_SESSION['ruta']);
                        }
                        else if($_SESSION['ruta'] == "ofertas_es"){
                            $mensaje = "Ya tienes esta oferta.";
                            unset($_SESSION['ruta']);
                        }
                        else if($_SESSION['ruta'] == "ofertas_en"){
                            $mensaje = "You already have this offer.";
                            unset($_SESSION['ruta']);
                        }
                        else if($_SESSION['ruta'] == "main_cat"){
                            $mensaje = "Aquest correu ja està associat a un altre usuari.";
                            unset($_SESSION['ruta']);
                        }
                        else if($_SESSION['ruta'] == "main_es"){
                            $mensaje = "Este correo ya esta asociado a otro usuario.";
                            unset($_SESSION['ruta']);
                        }
                        else if($_SESSION['ruta'] == "main_en"){
                            $mensaje = "This email is already associated with another user.";
                            unset($_SESSION['ruta']);
                        }
                break;
                default:
                        $mensaje = $e->errorInfo[1]. ' - '.$e->errorInfo[2];
                break;
            }


        }else{
            switch($e->getCode()){
                case 1044:
                    if($_SESSION['ruta'] == "main_cat"){
                        $mensaje = "Usuari / Contrasenya incorrectes.";
                        unset($_SESSION['ruta']);
                    }
                    else if($_SESSION['ruta'] == "main_es"){
                        $mensaje = "Usuario / Contraseña incorrectos.";
                        unset($_SESSION['ruta']);
                    }
                    else if($_SESSION['ruta'] == "main_en"){
                        $mensaje = "User / Password incorrect.";
                        unset($_SESSION['ruta']);
                    }
                    default:
                        $mensaje = $e->getCode().' - '. $e->getMessage();
                    break;
            }
            
        }
        return $mensaje;
    }

    function mensaje(){
        switch($_SESSION["ruta"]){
            case  "ofertas_cat":
                $mensaje = "Oferta bescanviada correctament.";
            break;
            case  "ofertas_es":
                $mensaje = "Oferta canjeada correctamente.";
            break;
            case  "ofertas_es":
                $mensaje = "Offer successfully redeemed.";
            break;
            case  "main_cat":
                    $mensaje = "Usuari registrat correctament.";
            break;
            case  "main_es":
                $mensaje = "Usuario registrado correctamente.";
            break;
            case  "main_es":
                $mensaje = "User successfully registered.";
            break;
        }
        return $mensaje;
    }
    function abrirBD(){
        try{
            $servername = "localhost";
            $username = "root";
            $password = "mysql";
            $conexion = new PDO("mysql:host=$servername;dbname=proyectoDAW", $username, $password);
            // set the PDO error mode to exception
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $conexion ->exec("set names utf8");
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
        return $conexion;
    }

    function cerrarBD(){
        return null;
    }

    function selectOfertas($id_mercado){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from ofertas where id_mercado  = :id_mercado";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':id_mercado', $id_mercado);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }
        $conexion = cerrarBD();
        return $resultado;
    }

    function selectMercados(){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from mercados";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
 
         $conexion = cerrarBD();
 
         return $resultado;
    }

    function selectMercadoId($id_mercado){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from mercados where id_mercado = :id_mercado";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':id_mercado', $id_mercado);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
 
         $conexion = cerrarBD();
 
         return $resultado;
    }

    function insertUsuario($nombre, $contrasena, $correo, $puntos, $administrador){
        try{
            $conexion = abrirBD();
            $sentenciaText = "insert into usuarios (nombre, contrasena, correo, puntos, administrador) values(:nombre, :contrasena, :correo, :puntos, :administrador)";
            $sentencia = $conexion->prepare($sentenciaText);
    
            $sentencia-> bindParam(':nombre', $nombre);
            $sentencia-> bindParam(':contrasena', $contrasena);
            $sentencia-> bindParam(':correo', $correo);    
            $sentencia-> bindParam(':puntos', $puntos); 
            $sentencia-> bindParam(':administrador', $administrador); 
            $sentencia ->execute();
            $_SESSION["mensaje"] = mensaje();
            $_SESSION['ultimaId'] = $conexion->lastInsertId();  
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
            $datosUsuario['nombre'] = $nombre;
            $datosUsuario['contrasena'] = $contrasena;
            $datosUsuario['correo'] = $correo;
            $datosUsuario['mercados'] = [];
            $_SESSION['datosUsuario'] = $datosUsuario;
        }
        $conexion = cerrarBD();
       
    }

    function insertUsuario_has_Mercado($id_usuario, $id_mercado){
        try{
            $conexion = abrirBD();
            $sentenciaTextTipo = "insert into usuario_has_mercados (id_usuario, id_mercado) values(:id_usuario, :id_mercado)";
            $sentenciaTipo = $conexion->prepare($sentenciaTextTipo);

            $sentenciaTipo-> bindParam(':id_usuario', $id_usuario);
            $sentenciaTipo-> bindParam(':id_mercado', $id_mercado);
            $sentenciaTipo ->execute();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
        $conexion = cerrarBD();

    }
    function selectUsuarios(){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from usuarios";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
         $conexion = cerrarBD();
 
         return $resultado;
    }

    function selectUsuarioId($id_usuario){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from usuarios where id_usuario = :id_usuario";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':id_usuario', $id_usuario);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }
        $conexion = cerrarBD();
        return $resultado;
    }

    function selectAllOfertas(){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from ofertas";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
        $conexion = cerrarBD();

        return $resultado;
    }
    function selectOferta($id_oferta){
        try{
        $conexion = abrirBD();
        $sentenciaText = "select * from ofertas where id_oferta = :id_oferta";
        $sentencia = $conexion->prepare($sentenciaText);
        $sentencia-> bindParam(':id_oferta', $id_oferta);
        $sentencia ->execute();
        $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }

        $conexion = cerrarBD();

        return $resultado;
    }

    function restarPuntosUsuario($id_usuario, $puntos){
        try{
        $conexion = abrirBD();
        $sentenciaText = "update usuarios set puntos = :puntos where id_usuario = :id_usuario";
        $sentencia = $conexion->prepare($sentenciaText);
        $sentencia-> bindParam(':id_usuario', $id_usuario);
        $sentencia-> bindParam(':puntos', $puntos);
        $sentencia ->execute();
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }
        $conexion = cerrarBD();
    }

    function sumarPuntosUsuario($id_usuario, $puntos){
        try{
        $conexion = abrirBD();
        $sentenciaText = "update usuarios set puntos = :puntos where id_usuario = :id_usuario";
        $sentencia = $conexion->prepare($sentenciaText);
        $sentencia-> bindParam(':id_usuario', $id_usuario);
        $sentencia-> bindParam(':puntos', $puntos);
        $sentencia ->execute();
        switch($_SESSION['ruta']){
            case 'juego1_cat':
                    $_SESSION['mensaje'] = 'Punts afegits correctament.';
                break;
            case 'juego1_es':
                $_SESSION['mensaje'] = 'Puntos agregados correctamente.';
            break;
            case 'juego1_en':
                $_SESSION['mensaje'] = 'Points added successfully.';
            break;
            case 'juego2_cat':
                $_SESSION['mensaje'] = 'Punts afegits correctament.';
            break;
            case 'juego2_es':
                $_SESSION['mensaje'] = 'Puntos agregados correctamente.';
            break;
            case 'juego2_en':
                $_SESSION['mensaje'] = 'Points added successfully.';
            break;
            case 'juego3_cat':
                    $_SESSION['mensaje'] = 'Punts afegits correctament.';
                break;
            case 'juego3_es':
                $_SESSION['mensaje'] = 'Puntos agregados correctamente.';
            break;
            case 'juego3_en':
                $_SESSION['mensaje'] = 'Points added successfully.';
            break;
        }
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }
        $conexion = cerrarBD();
    }

    function insertUsuarioHasOfertas($id_usuario, $id_oferta){
        try{
        $conexion = abrirBD();
        $sentenciaTextTipo = "insert into usuario_has_ofertas (id_usuario, id_oferta) values(:id_usuario, :id_oferta)";
        $sentenciaTipo = $conexion->prepare($sentenciaTextTipo);

        $sentenciaTipo-> bindParam(':id_usuario', $id_usuario);
        $sentenciaTipo-> bindParam(':id_oferta', $id_oferta);
        $sentenciaTipo ->execute();
        $_SESSION["mensaje"] = mensaje();
        }catch(PDOException $e){
            $_SESSION["error"] = error($e);
        }
        $conexion = cerrarBD();
    }

    function selectUsuarioHasOfertas(){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from usuario_has_ofertas";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }

        $conexion = cerrarBD();

        return $resultado;
    }

    function selectUsuarioHasOfertasId($id_usuario){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from usuario_has_ofertas where id_usuario = :id_usuario";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':id_usuario', $id_usuario);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
       

        $conexion = cerrarBD();

        return $resultado;
    }


    function selectUsuarioHasMercados(){
        try{
            $conexion = abrirBD();
            $sentenciaText = "select * from usuario_has_mercados";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia ->execute();
            $resultado = $sentencia->fetchAll();
        }
        catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
        $conexion = cerrarBD();

        return $resultado;
    }

    function updateUsuario($nombre, $contrasena, $correo, $id_usuario){
        try{
            $conexion = abrirBD();
            $sentenciaText = "update usuarios set nombre = :nombre, contrasena= :contrasena, correo= :correo where id_usuario = :id_usuario";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':nombre', $nombre);
            $sentencia-> bindParam(':contrasena', $contrasena);
            $sentencia-> bindParam(':correo', $correo);
            $sentencia-> bindParam(':id_usuario', $id_usuario);
            $sentencia ->execute();
            
            switch($_SESSION['ruta']){
                case 'perfil_cat':
                        $_SESSION['mensaje'] = 'Usuari editat correctament.';
                    break;
                case 'perfil_es':
                    $_SESSION['mensaje'] = 'Usuario editado correctamente.';
                break;
                case 'perfil_en':
                    $_SESSION['mensaje'] = 'User edited successfully.';
                break;
            }

        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
       

        $conexion = cerrarBD();

    

    }

    function updateAdmin($nombre, $contrasena, $correo, $puntos, $id_usuario){
        try{
            $conexion = abrirBD();
            $sentenciaText = "update usuarios set nombre = :nombre, contrasena= :contrasena, correo= :correo, puntos= :puntos where id_usuario = :id_usuario";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':nombre', $nombre);
            $sentencia-> bindParam(':contrasena', $contrasena);
            $sentencia-> bindParam(':correo', $correo);
            $sentencia-> bindParam(':puntos', $puntos);
            $sentencia-> bindParam(':id_usuario', $id_usuario);
            $sentencia ->execute();

            switch($_SESSION['ruta']){
                case 'perfil_cat':
                        $_SESSION['mensaje'] = 'Administrador editat correctament.';
                    break;
                case 'perfil_es':
                    $_SESSION['mensaje'] = 'Administrador editado correctamente.';
                break;
                case 'perfil_en':
                    $_SESSION['mensaje'] = 'Administrator edited successfully.';
                break;
            }

        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
       

        $conexion = cerrarBD();


    }

    function crearOferta($tipo_negocio, $puntos, $descripcion, $id_mercado){
        try{
            $conexion = abrirBD();
            $sentenciaText = "insert into ofertas (tipo_negocio, coste_puntos, descripcion, id_mercado) values (:tipo_negocio, :puntos, :descripcion, :id_mercado)";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':tipo_negocio', $tipo_negocio);
            $sentencia-> bindParam(':puntos', $puntos);
            $sentencia-> bindParam(':descripcion', $descripcion);
            $sentencia-> bindParam(':id_mercado', $id_mercado);
            $sentencia ->execute();

            switch($_SESSION['ruta']){
                case 'perfil_cat':
                        $_SESSION['mensaje'] = 'Oferta creada correctament.';
                    break;
                case 'perfil_es':
                    $_SESSION['mensaje'] = 'Oferta creada correctamente.';
                break;
                case 'perfil_en':
                    $_SESSION['mensaje'] = 'Offer created successfully.';
                break;
            }

        }catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
       

        $conexion = cerrarBD();

    };
    function eliminarUsuario($id_usuario){
        try{
            $conexion = abrirBD();
            $sentenciaText = "delete from usuarios where id_usuario = :id_usuario";
            $sentencia = $conexion->prepare($sentenciaText);
            $sentencia-> bindParam(':id_usuario', $id_usuario);
            $sentencia ->execute();
            switch($_SESSION['ruta']){
                case 'main_cat':
                        $_SESSION['mensaje'] = 'Usuari eliminat correctament.';
                    break;
                case 'main_es':
                    $_SESSION['mensaje'] = 'Usuario eliminado correctamente.';
                break;
                case 'main_cat':
                    $_SESSION['mensaje'] = 'User deleted successfully.';
                break;
            }
        }
        catch(PDOException $e){
            $_SESSION['error'] = error($e);
        }
        $conexion = cerrarBD();

    }

    


?>