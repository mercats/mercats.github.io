<?php
        session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercats BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_main.css">
</head>
<body>
    <div class="main_body">
        <header>
            <?php
                if(isset($_SESSION['id_usuario'])){
                    include_once("php_navbars_main/main_login.php");
                }
                else{
                    include_once("php_navbars_main/main_no_login.php");
                }   
            ?>
        </header>

        <main>
        <?php include_once('php_partials/mensaje.php')?>
            <div class="col-md-6 main_div main_div1 w3-animate-opacity">
                <p class="w3-animate-opacity">
                    Arran de la situació actual ocasionada per la pandèmia de la Covid-19, molts mercats i comerços locals es troben en una situació delicada. Establiments que durant anys han ofert serveis de venda de béns de primera necessitat es troben amb una afluència de clients molt reduïda, fet que comporta pèrdues considerables per aquests negocis. Aquesta iniciativa pretén incentivar els mercats locals, donant a conèixer la seva situació. Per tal d'aconseguir aquest objectiu, en aquest web us presentem diferents vies d'acció. Per un costat disposeu d'un apartat de minijocs on podreu acumular punts i bescanviar-los per descomptes en els mercats locals. També disposem d'un llistat on es mostren tots els mercats de Barcelona per si us interessa accedir a informació més detallada. Conscienciant-nos i aportant el nostre granet de sorra tots podem fer que aquests negocis que fa dècades que ens alimenten i cuiden puguin suportar aquesta situació.
                </p>
            </div>

            <div class="col-md-6 main_div main_div2">

                <div class="case case_1 w3-animate-top">
                    <a href="./ofertes.php">
                        <img src="./images/Offers_button.png">
                        <h1>Ofertes</h1>
                    </a>
                </div>

                <div class="case case_2 w3-animate-top">
                    <a href="./jocs.php">
                        <img src="./images/Game_button.png">
                        <h1>Jocs</h1>
                    </a>
                </div>

                <div class="case case_3 w3-animate-top">
                    <a href="./mercats_bcn.php">
                        <img src="./images/Market_button.png">
                        <h1>Mercats de Barcelona</h1>
                    </a>
                </div>
    
                <div class="case case_4 w3-animate-top">
                    <a href="./qui_som.php">
                        <img src="./images/People_button.png">
                        <h1>Qui som</h1>
                    </a>
                </div>

            </div>
        </main>
    
        </footer>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>