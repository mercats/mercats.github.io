<?php
        session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BCN Markets</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_jocs.css">
</head>
<body>
    <header>
        <?php
            if(isset($_SESSION['id_usuario'])){
                include_once("php_navbars_jocs/jocs_login_en.php");
            }
            else{
                include_once("php_navbars_jocs/jocs_no_login_en.php");
            }
        ?>
    </header>
    
    <main>

        <div class="games_div games_div1 col-md-6 w3-animate-opacity">
            <div class="game_explanation">
                <p>
                    In this section you will find a series of games that represent the adventures that must be carried out so that the products you want to buy in the market arrive
                    in the shops. From the delivery man who collects the products to the suppliers, through the journey they must make, until they are finally distributed
                    and they buy in the market.
                    <br/>
                    <br/>
                    With the games shown below you will be able to accumulate points and see various discounts and offers. Make sure to check what offers
                      They adapt to your needs, in the offers section.
                </p>

            </div>
        </div>

        <?php if(isset($_SESSION['id_usuario'])){?>
            <div class="games_div games_div2 col-md-6">

            <div class="game game1 w3-animate-left">
                <a href="./juego_1/index.php">
                    <h1>Reco-loco</h1>
                    
                </a>
            </div>

            <div class="game game2 w3-animate-right">
                <a href="./juego_2/index.php">
                    <h1>Trip to Market</h1>
                    
                </a>
            </div>

            <div class="game game3 w3-animate-left">
                <a href="./juego_3/juego_en.php">
                    <h1>Work in the market</h1>
                    
                </a>
            </div>

            <div class="game game4 w3-animate-right">
                <a href="./juego_4/joc-rca-no-canvas.php">
                    <h1>Delivery Man</h1>
                </a>
            </div>
                
        </div>     
        <?php }
        else{?>
             <div class="games_div games_div2 col-md-6">

            <div class="game game1 w3-animate-left">
                <a  style="cursor:not-allowed">
                    <h1>Reco-loco</h1><br>
                    <h6>Login to play</h6>
                </a>
            </div>

            <div class="game game2 w3-animate-right" >
                <a  style="cursor:not-allowed">
                <h1>Trip to Market</h1><br>
                <h6>Login to play</h6>
                </a>
            </div>

            <div class="game game3 w3-animate-left">
                <a style="cursor:not-allowed">
                <h1>Work in the market</h1><br>
                <h6>Login to play</h6>
                </a>
            </div>

            <div class="game game4 w3-animate-right">
                <a style="cursor:not-allowed">
                    <h1>Delivery Man</h1><br>
                    <h6>Login to play</h6>
                </a>
            </div>
                
            </div>
        <?php }?>   



































        
    </main>

    <footer>
        
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>