window.onload = function(){

    var img_landing = document.getElementById('div1');
    var images = [
        "./images/Fish.png",
        "./images/Meat.png",
        "./images/Bread.png",
        "./images/Strawberries.png",
        "./images/Tomatoes.png"
    ]

    console.log(img_landing);

    var i = 0;
    
    setInterval(function() {
          img_landing.style.backgroundImage = "url(" + images[i] + ")";
          i = i + 1;
          if (i == images.length) {
            i =  0;
          }
    }, 5000);

}