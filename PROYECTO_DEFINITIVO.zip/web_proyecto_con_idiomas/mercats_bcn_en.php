<?php
        session_start();
        require_once('./php_librarys/bd.php');
        $mercados = selectMercados();
        $numMercado = 0;
        $posicioMercatLeft = false;
        $mercadoNoAlimentarioShow = false;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BCN Markets</title>
    <link rel="stylesheet" href="./styles/styles_propios_mercats_bcn.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
    <div class="mercats_body">
        <div class="mercats_body2">
                <header>
                    <?php
                        if(isset($_SESSION['id_usuario'])){
                            include_once("php_navbars_mercats_bcn/mercats_bcn_login_en.php");
                        }
                        else{
                            include_once("php_navbars_mercats_bcn/mercats_bcn_no_login_en.php");
                        }
                        
                    ?>
                </header>
            
            <main>
                <div class="mercats_div mercats_div1 col-md-6 w3-animate-opacity">
                        <p>
                            Below is a list of all the markets located in the city of Barcelona. By clicking on the links, they will take you to the official websites of these markets.
                            For markets that do not have their own website,they will be redirected to the website of the Barcelona city council regarding the market in question.
                        </br>
                        Following the declaration of the alarm status to prevent the spread of covid-19, markets have adapted and strengthened their online and home shopping services to facilitate the purchase from home to the public. To consult the markets that offer these services click on the following link:
                        </p>
                        <a href="https://ajuntament.barcelona.cat/mercats/ca/canal/serveis-als-mercats">Services</a>
        
                </div>

                <div class="mercats_div col-md-6 mercats_div2">
                        <div class="div_list div_list_al">
                            <h1 class="h1_mercats w3-animate-opacity">Alimentary Market</h1>
                                <?php foreach($mercados as $mercado){
                                    if($numMercado <=19){?>
                                        <ul>
                                        <?php if($posicioMercatLeft == false){?>
                                        <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = true;
                                        }
                                        else if($posicioMercatLeft == true){?>
                                            <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                            <?php $numMercado = $numMercado +1;
                                            $posicioMercatLeft = false;
                                        } ?>
                                        </ul>
                                    <?php } 
                                    else if($numMercado > 19 && $numMercado <= 38){?>
                                        <ul>
                                        <?php if($posicioMercatLeft == false){?>
                                        <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = true;
                                        }
                                        else if($posicioMercatLeft == true){?>
                                            <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                            <?php $numMercado = $numMercado +1;
                                            $posicioMercatLeft = false;
                                        } ?>
                                        </ul>
                                    <?php }   
    
                                    else if($numMercado >= 39){
                                        if($mercadoNoAlimentarioShow == false){?>
                                            <div style="margin-top: 50%; position:absolute"><h1 class="h1_mercats w3-animate-opacity">Non-Alimentary Market</h1>
                                            <?php $mercadoNoAlimentarioShow = true;
                                             } ?>
                                        <ul>
                                        <?php if($posicioMercatLeft == false){?>
                                        <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = true;
                                        }
                                        else if($posicioMercatLeft == true){?>
                                            <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                            <?php $numMercado = $numMercado +1;
                                            $posicioMercatLeft = false;
                                        } ?>
                                        </ul>
                                    <?php }   
                                   }?>
                            </div>
                        </div>
                    </div>
            </main>

            <footer>
                
            </footer>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>