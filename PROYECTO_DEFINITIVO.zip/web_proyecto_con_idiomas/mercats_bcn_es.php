<?php
        session_start();
        require_once('./php_librarys/bd.php');
        $mercados = selectMercados();
        $numMercado = 0;
        $posicioMercatLeft = false;
        $mercadoNoAlimentarioShow = false;
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mercados BCN</title>
        <link rel="stylesheet" href="./styles/styles_propios_mercats_bcn.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>
        <div class="mercats_body">
            <div class="mercats_body2">
                <header>
                    <?php
                         if(isset($_SESSION['id_usuario'])){
                            include_once("php_navbars_mercats_bcn/mercats_bcn_login_es.php");
                        }
                        else{
                            include_once("php_navbars_mercats_bcn/mercats_bcn_no_login_es.php");
                        }
                    ?>
                </header>
            
            <main>
                <div class="mercats_div mercats_div1 col-md-6 w3-animate-opacity">
                        <p>
                            A continuación se muestra un listado con todos los mercados ubicados en la ciudad de Barcelona. Al hacer click en los enlaces, estos te llevarán a las páginas web oficiales de estos mercados.
                            Para los mercados que no disponen de una web propia, se redirigirá a la web del ayuntamiento de Barcelona referente al mercado en cuestión.
                        </br>
                        A raíz de la declaración del estado de alarma para evitar la propagación de la Covid-19, los mercados se han adaptado y reforzado sus servicios de compra online y a domicilio para facilitar la compra desde casa a la ciudadanía. Para consultar los mercados que ofrecen estos servicios haga click en el siguiente enlace:
                        </p>
                        <a href="https://ajuntament.barcelona.cat/mercats/ca/canal/serveis-als-mercats">Servicios</a>
        
                </div>

                <div class="mercats_div col-md-6 mercats_div2">
                    <div class="div_list div_list_al">
                        <h1 class="h1_mercats w3-animate-opacity">Mercados Alimentarios</h1>
                              <?php foreach($mercados as $mercado){
                                if($numMercado <=19){?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php } 
                                else if($numMercado > 19 && $numMercado <= 38){?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php }   

                                else if($numMercado >= 39){
                                    if($mercadoNoAlimentarioShow == false){?>
                                        <div style="margin-top: 50%; position:absolute"><h1 class="h1_mercats w3-animate-opacity">Mercados No-Alimentarios</h1>
                                        <?php $mercadoNoAlimentarioShow = true;
                                         } ?>
                                    <ul>
                                    <?php if($posicioMercatLeft == false){?>
                                    <li class="links w3-animate-left"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                    <?php $numMercado = $numMercado +1;
                                    $posicioMercatLeft = true;
                                    }
                                    else if($posicioMercatLeft == true){?>
                                        <li class="links w3-animate-right"><a href="<?php echo $mercado['url']?>"><?php echo $mercado['nombre']?></a></li>
                                        <?php $numMercado = $numMercado +1;
                                        $posicioMercatLeft = false;
                                    } ?>
                                    </ul>
                                <?php }   
                               }?>
                        </div>
                    </div>
                </div>     
            </main>

            <footer>
                
            </footer>
        </div>
        </div>
    </body>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>