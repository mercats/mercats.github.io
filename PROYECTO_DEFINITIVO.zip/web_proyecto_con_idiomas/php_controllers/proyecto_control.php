<?php
        session_start();
        require_once("../php_librarys/bd.php");
        
        $mercadoEncontrado = false;
        $mercadoNum = 1;
        switch($_POST['lang']){
            case 'ofertas_cat': $ruta = "/web_proyecto_con_idiomas/ofertes.php";
                                $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'ofertas_es': $ruta = "/web_proyecto_con_idiomas/ofertes_es.php";
                               $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'ofertas_en': $ruta = "/web_proyecto_con_idiomas/ofertes_en.php";
                               $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'main_cat': $ruta = "/web_proyecto_con_idiomas/main.php";
                             $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'main_es': $ruta = "/web_proyecto_con_idiomas/main_es.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'main_en': $ruta = "/web_proyecto_con_idiomas/main_en.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego1_cat': $ruta = "/web_proyecto_con_idiomas/juego_1/index.php";
            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego1_es': $ruta = "/web_proyecto_con_idiomas/juego_1/index_es.php";
                        $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego1_en': $ruta = "/web_proyecto_con_idiomas/juego_1/index_en.php";
                        $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego2_cat': $ruta = "/web_proyecto_con_idiomas/juego_2/index.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego2_es': $ruta = "/web_proyecto_con_idiomas/juego_2/index_es.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego2_en': $ruta = "/web_proyecto_con_idiomas/juego_2/index_en.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego3_cat': $ruta = "/web_proyecto_con_idiomas/juego_3/juego.php";
            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego3_es': $ruta = "/web_proyecto_con_idiomas/juego_3/juego_es.php";
                        $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'juego3_en': $ruta = "/web_proyecto_con_idiomas/juego_3/juego_en.php";
                        $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'perfil_cat': $ruta = "/web_proyecto_con_idiomas/perfil.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'perfil_es': $ruta = "/web_proyecto_con_idiomas/perfil_es.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
            case 'perfil_en': $ruta = "/web_proyecto_con_idiomas/perfil_en.php";
                            $_SESSION['ruta'] = $_POST['lang'];
            break;
        }
        
        if(isset($_POST['insertar'])){
            insertUsuario($_POST['nom'], $_POST['contrasenya'], $_POST['email'], 0, 0);
            $mercados = $_POST['mercat'];
            if(isset($_SESSION['ultimaId'])){
                foreach($mercados as $mercado){
                    if(!isset($_SESSION['datosUsuario'])){
                        insertUsuario_has_Mercado($_SESSION['ultimaId'], $mercado);
                    }
                }
                $_SESSION['id_usuario'] = $_SESSION['ultimaId'];
                unset($_SESSION['ultimaId']);
            }else{
                $datosUsuario  =  $_SESSION['datosUsuario'];
                $datosUsuario['mercados'] = $_POST['mercat'];
                $_SESSION['datosUsuario'] = $datosUsuario;
            }
          

            if(isset($_SESSION['error'])){
                if($_POST['lang']=='main_cat'){
                    header("Location: ../registre.php");
                    exit();
                }else if($_POST['lang']=='main_es'){
                    header("Location: ../registre_es.php");
                    exit();
                }else if($_POST['lang']=='main_en'){
                    header("Location: ../registre_en.php");
                    exit();
                }
                
            }else{
                header("Location: $ruta");
                exit();
            }

        }

        if(isset($_POST['usuarioEntrar'])){
            $usuarios= selectUsuarios();
            $usuarioEncontrado = false;
            foreach($usuarios as $usuario){
                if($usuario['correo'] == $_POST['email'] && $usuario['contrasena'] == $_POST['contrasenya']){
                    $_SESSION['id_usuario'] = $usuario['id_usuario'];
                    $_SESSION["mostrarTodosLosMercados"] = false;
                    $usuarioEncontrado = true;
                    unset($_SESSION['Mercado']);
                    header("Location: $ruta");
                    exit(); 
                }
            }
            if($usuarioEncontrado == false){
                $_SESSION['error'] = "Correo / Contraseña incorrectos.";
                $datosUsuario['contrasena'] = $_POST['contrasena'];
                $datosUsuario['correo'] = $_POST['email'];
                $_SESSION['datosUsuario'] = $datosUsuario;
                if($_POST['lang']=='main_cat'){
                    header("Location: ../usuari.php");
                    exit();
                }else if($_POST['lang']=='main_es'){
                    header("Location: ../usuari_es.php");
                    exit();
                }else if($_POST['lang']=='main_en'){
                    header("Location: ../usuari_en.php");
                    exit();
                }
            } 
            
        }

        if(isset($_POST['cerrarSesion'])){
            session_destroy();
            header("Location: ../main.php");
            exit();
        }

        if(isset($_POST['canjearOferta'])){
            $usuarios = selectUsuarioId($_SESSION['id_usuario']);
            foreach($usuarios as $usuario){
                $puntosUsuario = $usuario['puntos'];
            }
            $ofertas = selectOferta($_POST['inputIdOferta']);
            foreach($ofertas as $oferta){
                $puntosOferta = $oferta['coste_puntos'];
            }
            if($puntosUsuario >= $puntosOferta){
                $puntosUsuario = $puntosUsuario - $puntosOferta;
                insertUsuarioHasOfertas($_SESSION['id_usuario'], $_POST['inputIdOferta']);
                if(!isset($_SESSION['error'])){
                    restarPuntosUsuario($_SESSION['id_usuario'], $puntosUsuario);
                }
                header("Location: $ruta");
                exit();
            }
            else{
                switch($_POST['lang']){
                    case 'ofertes_cat':
                        $_SESSION['error'] = "No téns suficients punts.";
                    break;
                    case 'ofertes_es':
                        $_SESSION['error'] = "No tienes suficientes puntos.";
                    break;
                    case 'ofertes_en':
                        $_SESSION['error'] = "You don't have enough points.";
                    break;
                };
                
                header("Location: $ruta");
                exit();
            }
        }
        if(isset($_POST['buscarOfertas'])){
            $_SESSION['mercadoSeleccionado'] = $_POST['opcionMercado'];
            $_SESSION['ofertasMercado'] = selectOfertas($_POST["opcionMercado"]);
            $mercados = selectMercadoId($_POST['opcionMercado']);
            foreach($mercados as $mercado){
                $_SESSION['nombreMercado'] = $mercado['nombre'];
            }
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST['tipoMercado'])){
            $_SESSION['tipoMercado'] = $_POST['tipoMercado'];
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST["MostrarTodosLosMercados"])){
            $_SESSION["mostrarTodosLosMercados"] = true;
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST["MostrarTusMercados"])){
            $_SESSION["mostrarTodosLosMercados"] = false;
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST['botonGuardarPuntuacion'])){
            $usuarios = selectUsuarioId($_SESSION['id_usuario']);
            foreach($usuarios as $usuario){
                $puntuacionInicial = $usuario['puntos'];
            }
            $puntuacionCookie = $_COOKIE["puntuacion"];
            unset($_COOKIE['puntuacion']);
            $puntuacionFinal = $puntuacionInicial + $puntuacionCookie;
            sumarPuntosUsuario($_SESSION['id_usuario'], $puntuacionFinal);
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST['cambiarDatos'])){
            $nombre = $_POST['nombre'];
            $correo = $_POST['correo'];
            $contrasena = $_POST['contrasena'];
            $id_usuario = $_POST['inputIdUsuario'];
            updateUsuario($nombre, $contrasena, $correo, $id_usuario);
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST['cambiarDatosAdmin'])){
            $nombre = $_POST['nombre'];
            $correo = $_POST['correo'];
            $contrasena = $_POST['contrasena'];
            $puntos = $_POST['puntos'];
            $id_usuario = $_POST['inputIdUsuario'];
            updateAdmin($nombre, $contrasena, $correo, $puntos, $id_usuario);
            header("Location: $ruta");
            exit();
        }

        if(isset($_POST['crearOferta'])){
            $tipoNegocio = $_POST['tipoNegocio'];
            $costePuntos = $_POST['costePuntos'];
            $descripcion = $_POST['descripcion'];
            $id_mercado = $_POST['id_mercado'];
            crearOferta($tipoNegocio, $costePuntos, $descripcion, $id_mercado);
            if(!isset($_SESSION['error'])){
            switch($_POST['lang']){
                case 'perfil_cat':
                    $_SESSION['mensaje'] = "Oferta creada correctament.";
                break;
                case 'perfil_es':
                    $_SESSION['mensaje'] = "Oferta creada correctamente.";
                break;
                case 'perfil_en':
                    $_SESSION['mensaje'] = "Offer created successfully.";
                break;
            }
            }
            header("Location: $ruta");
            exit();
        }
        if(isset($_POST['eliminarUsuari'])){
            eliminarUsuario($_POST['id_usuario']);
            session_destroy();
            header("Location: $ruta");
            exit();
        }
        
            
?>