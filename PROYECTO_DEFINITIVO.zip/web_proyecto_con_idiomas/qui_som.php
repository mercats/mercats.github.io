<?php
        session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercats BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="./styles/styles_propios_qui_som.css">
</head>
<body>
    <header>
        <?php
            if(isset($_SESSION['id_usuario'])){
                include_once("php_navbars_qui_som/qui_som_login.php");
            }
            else{
                include_once("php_navbars_qui_som/qui_som_no_login.php");
            }
            
        ?>
    </header>

    <main>

        <div class="us_div us_div1 col-md-6 w3-animate-opacity">
            <div class="us_explanation">
                <p>
                    CEPSoft Consulting és una empresa jove situada al centre de Barcelona. Ens dediquem al desenvolupament de solucions web creant projectes personalitzats i a la mida de les necessitats dels nostres clients.
                    Actualment tenim una plantilla de 40 creadors informàtics amb ganes d’aportar solucions innovadores i atractives als nostres clients. El nostre equip és molt jove i dinàmic, amb ganes d’afrontar els reptes que se'ns presenten amb imaginació, il·lusió i implicació. 
                    <br/><br/>Una vegada acceptem un repte volem trobar la millor solució, per a nosaltres això significa:
                    <br/><strong>Resoldre el problema.</strong>
                    <br/><strong>Donar la millor solució tècnica.</strong>
                    <br/><strong>Donar una solució útil, fàcil per l’usuari, elegant, creativa, diferent i impactant. Volem posar-li les coses fàcils al departament de màrqueting.</strong>
                    <br/>cepsoft@cep.net
                </p>

            </div>
        </div>

        <div class="container d-flex justify-content-center col-md-6 us">
            <div class="row">
                <div class="col-md-6 w3-animate-left pers">
                    <div class="card p-3 py-1 mt-3 ampliar">
                        <div class="text-center"><img src="images/roger.png" width="100px" height="120px" class="rounded-circle pics"></a>
                            <input type="checkbox" id="personal1"></input>
                            <label for="personal1">Roger Comorera <br/>Agustí</label> 
                            <div class="personal"><h2 class="desc">Tinc 28 anys, sóc una persona una mica reservada, de caràcter seriós. M'agraden els animals, apassionat de la música i m'atrauen els jocs, tant de taula com d'ordinador.
                            Fa poc vaig descobrir el meu interès per la informàtica i actualment em trobo treballant i estudiant per poder donar un canvi a la meva vida professional per poder dedicar-me a aquest nou món que dia a dia m'ofereix noves oportunitats.</h2></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 w3-animate-right pers">
                    <div class="card p-3 py-1 mt-3 ampliar">
                        <div class="text-center"> <img src="images/arnau.png" width="100px" height="120px" class="rounded-circle pics">
                            <input type="checkbox" id="personal2"></input>
                            <label for="personal2">Arnau Bayó<br/>García</label>
                            <div class="personal"><h2 class="desc">Tinc 21 anys, sóc una persona una mica tímida, gran amant de l'esport físic i dels esports de contacte. Estic estudiant programació donat que és un camp que em resulta molt interessant i ofereix moltes possibilitats laborals.</h2></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 w3-animate-left pers">
                    <div class="card p-3 py-1 mt-5 ampliar">
                        <div class="text-center"> <img src="images/dani.png" width="100px" height="120px" class="rounded-circle pics">
                            <input type="checkbox" id="personal3"></input>
                            <label for="personal3">Daniel Fernández<br/>Jiménez</label>
                            <div class="personal"><h2 class="desc">Tinc 22 anys, em defineixo com una persona extravertida, carismàtica i alegre. M'agrada superar les meves expectatives cada dia i passar temps amb la gent del meu voltant, però també tinc moments en què prefereixo estar una mica més relaxat.
                            El meu interès per la informàtica va néixer gràcies als videojocs, i cada vegada em veig més a prop del meu objectiu.</h2></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 w3-animate-right pers">
                    <div class="card p-3 py-1 mt-5 ampliar">
                        <div class="text-center"><img src="images/oscar.png" width="100px" height="120px" class="rounded-circle pics"></a>
                            <input type="checkbox" id="personal4"></input>
                            <label for="personal4">Óscar González <br/>Zarrias</label>
                            <div class="personal"><h2 class="desc">Tinc 22 anys, sóc introvertit, curiós i independent. M'encanta anar a cinema i escoltar heavy metal mentre passeig o recorro el món amb els meus patins en línia. M'interessa la programació per la infinitat de possibilitats que ofereix a l'abast de tots, espero treballar-hi i fer grans coses.</h2></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>            
    </main>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>