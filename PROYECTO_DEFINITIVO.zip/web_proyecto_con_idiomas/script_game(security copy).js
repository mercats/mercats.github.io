window.onload = function(){


var pj = document.getElementById("pj");
var game_area = document.getElementById("game_area");
var cargo_request = document.getElementById("cargo_request");
var cargo_area = document.getElementById("cargo_area");
var score = 0;
document.getElementById("score").innerHTML = score;
var score_up = 10;
var speed = 5;
var arrow_left = 37; // 37 = codi de la tecla fletxa esquerra del teclat
var arrow_right = 39;
var arrow_top = 38;
var arrow_bottom = 40;
var random_delivery = 0;
var random_obj = 0;
var url_obj = "";
var cargo_check = false;

cargo_request.style.display = "none";

var request_array = [
    document.getElementById('request1'),
    document.getElementById('request2'),
    document.getElementById('request3'),
    document.getElementById('request4'),
];
var delivery_area_array = [
    document.getElementById('delivery_area1'),
    document.getElementById('delivery_area2'),
    document.getElementById('delivery_area3'),
    document.getElementById('delivery_area4'),
];

//Peticions a entregar------------------------------------------------------
function ronda_entrega(){

    cargo_request.style.display = "block";
    random_delivery = (Math.round(Math.random() * 3)); //Num random de 0 a 3
    random_obj = (Math.round(Math.random() * 3));
    
    if (random_obj == 0){
        url_obj = "url('./game_images/fruits.png')";
    } else if (random_obj == 1){
        url_obj = "url('./game_images/meat.png')";
    } else if (random_obj ==2){
        url_obj = "url('./game_images/bakery.png')";
    } else if (random_obj == 3){
        url_obj = "url('./game_images/fish.png')";
    }

    cargo_request.style.background = url_obj; //Mostrar en el camio la imatge a entregar

    //Mostrar productes i activar area de la casa
    request_array[random_delivery].style.background = url_obj;
    request_array[random_delivery].style.display = "block";
    delivery_area_array[random_delivery].style.display ="block";
    cargo_area.style.display = "block";
}
//Fi peticions a entregar--------------------------------------------------


document.addEventListener('keydown', function(key){ //Funció per determinar el moviment del div "pj"
//Algorisme per agafar els valors de tamany de l'estil associat al div "pj" i convertir-lo en int
var pj_left_string = window.getComputedStyle(pj, null).getPropertyValue('left');
var pj_left_int = parseInt(pj_left_string);

var pj_top_string = window.getComputedStyle(pj, null).getPropertyValue('top');
var pj_top_int = parseInt(pj_top_string);

var pj_width_string = window.getComputedStyle(pj, null).getPropertyValue('width');
var pj_width_int = parseInt(pj_width_string);

var pj_height_string = window.getComputedStyle(pj, null).getPropertyValue('height');
var pj_height_int = parseInt(pj_height_string);
//-------------------------------------------------------------------------------------------------------------

//Algorisme per agafar els valors de tamany de l'estil associat al div "game_area" i convertir-lo en int
var game_area_left_string = window.getComputedStyle(game_area, null).getPropertyValue('left');
var game_area_left_int = parseInt(game_area_left_string);

var game_area_top_string = window.getComputedStyle(game_area, null).getPropertyValue('top');
var game_area_top_int = parseInt(game_area_top_string);

var game_area_width_string = window.getComputedStyle(game_area, null).getPropertyValue('width');
var game_area_width_int = parseInt(game_area_width_string);

var game_area_height_string = window.getComputedStyle(game_area, null).getPropertyValue('height');
var game_area_height_int = parseInt(game_area_height_string);
//-------------------------------------------------------------------------------------------------------------
   
    var speedx = 0;
    var speedy = 0;

    //Controlar moviment + colisions amb els marges de la pantalla-------------------------------------------
    if (pj_left_int - speed < game_area_left_int && key.keyCode == arrow_left) { //fletxa esquerra
        pj_left_int = 0;
    } else if (key.keyCode == arrow_left) {
        speedx = speedx - speed;
    }   

    if (pj_left_int + pj_width_int + speed > game_area_left_int + game_area_width_int && key.keyCode == arrow_right){ //fletxa dreta
        pj_left_int = game_area_left_int + game_area_width_int - pj_width_int;
    } else if (key.keyCode == arrow_right){
        speedx = speedx + speed;
    }

    if (pj_top_int - speed < game_area_top_int && key.keyCode == arrow_top){ //fletxa amunt
        pj_top_int = 0;
    }else if (key.keyCode == arrow_top) {
        speedy = speedy - speed;
    }

    if (pj_top_int + pj_height_int + speed > game_area_top_int + game_area_height_int && key.keyCode == arrow_bottom){ //fletxa avall
        pj_top_int = game_area_top_int + game_area_height_int - pj_height_int;
    }else if (key.keyCode == arrow_bottom){
        speedy = speedy + speed;
    }
    //Fi colisio amb marges de la pantalla -----------------------------------------------------------------

    //Controlar entrada area carrega ----------------------------------------
    if (cargo_check == false){
            var cargo_area_left_string = window.getComputedStyle(cargo_area, null).getPropertyValue('left');
            var cargo_area_left_int = parseInt(cargo_area_left_string); //Marge esquerre de l'objecte (int)
            var cargo_area_width_string = window.getComputedStyle(cargo_area, null).getPropertyValue('width');
            var cargo_area_width_int = parseInt(cargo_area_width_string);
            var cargo_area_right_int = cargo_area_left_int + cargo_area_width_int; //Marge dret de l'objecte (int)
            var cargo_area_top_string = window.getComputedStyle(cargo_area, null).getPropertyValue('top');
            var cargo_area_top_int = parseInt(cargo_area_top_string); //Marge superior de l'objecte (int)
            var cargo_area_height_string = window.getComputedStyle(cargo_area, null).getPropertyValue('height');
            var cargo_area_height_int = parseInt(cargo_area_height_string); 
            var cargo_area_bottom_int = cargo_area_top_int + cargo_area_height_int;//Marge inferior de l'objecte (int)

            if(key.keyCode == arrow_right){ //Colisio amb objecte "cargo_area" per la dreta
                    if (pj_left_int + pj_width_int + speed > cargo_area_left_int && pj_left_int < cargo_area_right_int && pj_top_int + pj_height_int > cargo_area_top_int && pj_top_int < cargo_area_bottom_int){
                        ronda_entrega();
                        cargo_area.style.display = "none";
                        cargo_check = true;
                }
            }
            if(key.keyCode == arrow_left){ //Colisio amb objecte "cargo_area" per l'esquerra
                    if (pj_left_int - speed < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int > cargo_area_top_int && pj_top_int < cargo_area_bottom_int){
                        ronda_entrega();
                        cargo_area.style.display = "none";
                        cargo_check = true;
                }
            }
            if(key.keyCode == arrow_top){ //Colisio amb objecte "cargo_area" per sota
                    if (pj_top_int - speed < cargo_area_bottom_int && pj_left_int < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int > cargo_area_top_int){
                        ronda_entrega();
                        cargo_area.style.display = "none";
                        cargo_check = true;
                    }
            }
            if(key.keyCode == arrow_bottom){ //Colisio amb objecte "cargo_area" per dalt
                    if (pj_top_int + pj_height_int + speed > cargo_area_top_int && pj_left_int < cargo_area_right_int && pj_left_int + pj_width_int > cargo_area_left_int && pj_top_int + pj_height_int < cargo_area_bottom_int){
                        ronda_entrega();
                        cargo_area.style.display = "none";
                        cargo_check = true;
                    }
            }
    }
    //Fi controlar entrada area carrega -----------------------------------------------

    //Controlar entrada a l'area d'entrega ----------------------------------------
    if (cargo_check == true){
        var delivery_area_left_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('left');
        var delivery_area_left_int = parseInt(delivery_area_left_string); //Marge esquerre de l'objecte (int)
        var delivery_area_width_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('width');
        var delivery_area_width_int = parseInt(delivery_area_width_string);
        var delivery_area_right_int = delivery_area_left_int + delivery_area_width_int; //Marge dret de l'objecte (int)
        var delivery_area_top_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('top');
        var delivery_area_top_int = parseInt(delivery_area_top_string); //Marge superior de l'objecte (int)
        var delivery_area_height_string = window.getComputedStyle(delivery_area_array[random_delivery], null).getPropertyValue('height');
        var delivery_area_height_int = parseInt(delivery_area_height_string); 
        var delivery_area_bottom_int = delivery_area_top_int + delivery_area_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "delivery_area_array[random_delivery]" per la dreta
                if (pj_left_int + pj_width_int + speed > delivery_area_left_int && pj_left_int < delivery_area_right_int && pj_top_int + pj_height_int > delivery_area_top_int && pj_top_int < delivery_area_bottom_int){
                    score = score + score_up;
                    document.getElementById("score").innerHTML = score;
                    request_array[random_delivery].style.display = "none";
                    delivery_area_array[random_delivery].style.display ="none";
                    cargo_area.style.display = "block";
                    cargo_request.style.display = "none";
                    cargo_check = false;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "delivery_area_array[random_delivery]" per l'esquerra
                if (pj_left_int - speed < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int > delivery_area_top_int && pj_top_int < delivery_area_bottom_int){
                    score = score + score_up;  
                    document.getElementById("score").innerHTML = score;
                    request_array[random_delivery].style.display = "none";
                    delivery_area_array[random_delivery].style.display ="none";
                    cargo_area.style.display = "block";
                    cargo_request.style.display = "none";
                    cargo_check = false;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "delivery_area_array[random_delivery]" per sota
                if (pj_top_int - speed < delivery_area_bottom_int && pj_left_int < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int > delivery_area_top_int){
                    score = score + score_up;
                    document.getElementById("score").innerHTML = score;
                    request_array[random_delivery].style.display = "none";
                    delivery_area_array[random_delivery].style.display ="none";
                    cargo_area.style.display = "block";
                    cargo_request.style.display = "none";
                    cargo_check = false;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "delivery_area_array[random_delivery]" per dalt
                if (pj_top_int + pj_height_int + speed > delivery_area_top_int && pj_left_int < delivery_area_right_int && pj_left_int + pj_width_int > delivery_area_left_int && pj_top_int + pj_height_int < delivery_area_bottom_int){
                    score = score + score_up;
                    document.getElementById("score").innerHTML = score;
                    request_array[random_delivery].style.display = "none";
                    delivery_area_array[random_delivery].style.display ="none";
                    cargo_area.style.display = "block";
                    cargo_request.style.display = "none";
                    cargo_check = false;
                }
        }
    }
//Fi controlar entrada a l'area d'entrega-----------------------------------------------




    //Controlar colisio amb objectes  "store" ----------------------------------------
    var obj_store = document.querySelectorAll('.store');
   
    obj_store.forEach(function(store){ 
        var obj_store_left_string = window.getComputedStyle(store, null).getPropertyValue('left');
        var obj_store_left_int = parseInt(obj_store_left_string); //Marge esquerre de l'objecte (int)
        var obj_store_width_string = window.getComputedStyle(store, null).getPropertyValue('width');
        var obj_store_width_int = parseInt(obj_store_width_string);
        var obj_store_right_int = obj_store_left_int + obj_store_width_int; //Marge dret de l'objecte (int)
        var obj_store_top_string = window.getComputedStyle(store, null).getPropertyValue('top');
        var obj_store_top_int = parseInt(obj_store_top_string); //Marge superior de l'objecte (int)
        var obj_store_height_string = window.getComputedStyle(store, null).getPropertyValue('height');
        var obj_store_height_int = parseInt(obj_store_height_string); 
        var obj_store_bottom_int = obj_store_top_int + obj_store_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "store" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_store_left_int && pj_left_int < obj_store_right_int && pj_top_int + pj_height_int > obj_store_top_int && pj_top_int < obj_store_bottom_int){
                    pj_left_int = obj_store_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "store" per l'esquerra
                if (pj_left_int - speed < obj_store_right_int && pj_left_int + pj_width_int > obj_store_left_int && pj_top_int + pj_height_int > obj_store_top_int && pj_top_int < obj_store_bottom_int){
                    pj_left_int = obj_store_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "store" per sota
                if (pj_top_int - speed < obj_store_bottom_int && pj_left_int < obj_store_right_int && pj_left_int + pj_width_int > obj_store_left_int && pj_top_int + pj_height_int > obj_store_top_int){
                    pj_top_int = obj_store_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "store" per dalt
                if (pj_top_int + pj_height_int + speed > obj_store_top_int && pj_left_int < obj_store_right_int && pj_left_int + pj_width_int > obj_store_left_int && pj_top_int + pj_height_int < obj_store_bottom_int){
                    pj_top_int = obj_store_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "store" -----------------------------------------------

    //Controlar colisio amb objectes  "long_house" ----------------------------------------
    var obj_long_house = document.querySelectorAll('.long_house');
   
    obj_long_house.forEach(function(long_house){ 
        var obj_long_house_left_string = window.getComputedStyle(long_house, null).getPropertyValue('left');
        var obj_long_house_left_int = parseInt(obj_long_house_left_string); //Marge esquerre de l'objecte (int)
        var obj_long_house_width_string = window.getComputedStyle(long_house, null).getPropertyValue('width');
        var obj_long_house_width_int = parseInt(obj_long_house_width_string);
        var obj_long_house_right_int = obj_long_house_left_int + obj_long_house_width_int; //Marge dret de l'objecte (int)
        var obj_long_house_top_string = window.getComputedStyle(long_house, null).getPropertyValue('top');
        var obj_long_house_top_int = parseInt(obj_long_house_top_string); //Marge superior de l'objecte (int)
        var obj_long_house_height_string = window.getComputedStyle(long_house, null).getPropertyValue('height');
        var obj_long_house_height_int = parseInt(obj_long_house_height_string); 
        var obj_long_house_bottom_int = obj_long_house_top_int + obj_long_house_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "long_house" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_long_house_left_int && pj_left_int < obj_long_house_right_int && pj_top_int + pj_height_int > obj_long_house_top_int && pj_top_int < obj_long_house_bottom_int){
                    pj_left_int = obj_long_house_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "long_house" per l'esquerra
                if (pj_left_int - speed < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int > obj_long_house_top_int && pj_top_int < obj_long_house_bottom_int){
                    pj_left_int = obj_long_house_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "long_house" per sota
                if (pj_top_int - speed < obj_long_house_bottom_int && pj_left_int < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int > obj_long_house_top_int){
                    pj_top_int = obj_long_house_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "long_house" per dalt
                if (pj_top_int + pj_height_int + speed > obj_long_house_top_int && pj_left_int < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int < obj_long_house_bottom_int){
                    pj_top_int = obj_long_house_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "long_house" -----------------------------------------------

    //Controlar colisio amb objectes  "long_house" ----------------------------------------
    var obj_long_house = document.querySelectorAll('.long_house');
   
    obj_long_house.forEach(function(long_house){ 
        var obj_long_house_left_string = window.getComputedStyle(long_house, null).getPropertyValue('left');
        var obj_long_house_left_int = parseInt(obj_long_house_left_string); //Marge esquerre de l'objecte (int)
        var obj_long_house_width_string = window.getComputedStyle(long_house, null).getPropertyValue('width');
        var obj_long_house_width_int = parseInt(obj_long_house_width_string);
        var obj_long_house_right_int = obj_long_house_left_int + obj_long_house_width_int; //Marge dret de l'objecte (int)
        var obj_long_house_top_string = window.getComputedStyle(long_house, null).getPropertyValue('top');
        var obj_long_house_top_int = parseInt(obj_long_house_top_string); //Marge superior de l'objecte (int)
        var obj_long_house_height_string = window.getComputedStyle(long_house, null).getPropertyValue('height');
        var obj_long_house_height_int = parseInt(obj_long_house_height_string); 
        var obj_long_house_bottom_int = obj_long_house_top_int + obj_long_house_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "long_house" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_long_house_left_int && pj_left_int < obj_long_house_right_int && pj_top_int + pj_height_int > obj_long_house_top_int && pj_top_int < obj_long_house_bottom_int){
                    pj_left_int = obj_long_house_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "long_house" per l'esquerra
                if (pj_left_int - speed < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int > obj_long_house_top_int && pj_top_int < obj_long_house_bottom_int){
                    pj_left_int = obj_long_house_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "long_house" per sota
                if (pj_top_int - speed < obj_long_house_bottom_int && pj_left_int < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int > obj_long_house_top_int){
                    pj_top_int = obj_long_house_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "long_house" per dalt
                if (pj_top_int + pj_height_int + speed > obj_long_house_top_int && pj_left_int < obj_long_house_right_int && pj_left_int + pj_width_int > obj_long_house_left_int && pj_top_int + pj_height_int < obj_long_house_bottom_int){
                    pj_top_int = obj_long_house_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "long_house" -----------------------------------------------

    //Controlar colisio amb objectes  "long_house2" ----------------------------------------
    var obj_long_house2 = document.querySelectorAll('.long_house2');
   
    obj_long_house2.forEach(function(long_house2){ 
        var obj_long_house2_left_string = window.getComputedStyle(long_house2, null).getPropertyValue('left');
        var obj_long_house2_left_int = parseInt(obj_long_house2_left_string); //Marge esquerre de l'objecte (int)
        var obj_long_house2_width_string = window.getComputedStyle(long_house2, null).getPropertyValue('width');
        var obj_long_house2_width_int = parseInt(obj_long_house2_width_string);
        var obj_long_house2_right_int = obj_long_house2_left_int + obj_long_house2_width_int; //Marge dret de l'objecte (int)
        var obj_long_house2_top_string = window.getComputedStyle(long_house2, null).getPropertyValue('top');
        var obj_long_house2_top_int = parseInt(obj_long_house2_top_string); //Marge superior de l'objecte (int)
        var obj_long_house2_height_string = window.getComputedStyle(long_house2, null).getPropertyValue('height');
        var obj_long_house2_height_int = parseInt(obj_long_house2_height_string); 
        var obj_long_house2_bottom_int = obj_long_house2_top_int + obj_long_house2_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "long_house2" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_long_house2_left_int && pj_left_int < obj_long_house2_right_int && pj_top_int + pj_height_int > obj_long_house2_top_int && pj_top_int < obj_long_house2_bottom_int){
                    pj_left_int = obj_long_house2_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "long_house2" per l'esquerra
                if (pj_left_int - speed < obj_long_house2_right_int && pj_left_int + pj_width_int > obj_long_house2_left_int && pj_top_int + pj_height_int > obj_long_house2_top_int && pj_top_int < obj_long_house2_bottom_int){
                    pj_left_int = obj_long_house2_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "long_house2" per sota
                if (pj_top_int - speed < obj_long_house2_bottom_int && pj_left_int < obj_long_house2_right_int && pj_left_int + pj_width_int > obj_long_house2_left_int && pj_top_int + pj_height_int > obj_long_house2_top_int){
                    pj_top_int = obj_long_house2_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "long_house2" per dalt
                if (pj_top_int + pj_height_int + speed > obj_long_house2_top_int && pj_left_int < obj_long_house2_right_int && pj_left_int + pj_width_int > obj_long_house2_left_int && pj_top_int + pj_height_int < obj_long_house2_bottom_int){
                    pj_top_int = obj_long_house2_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "long_house2" -----------------------------------------------

    //Controlar colisio amb objectes  "corner_house" ----------------------------------------
    var obj_corner_house = document.querySelectorAll('.corner_house');
   
    obj_corner_house.forEach(function(corner_house){ 
        var obj_corner_house_left_string = window.getComputedStyle(corner_house, null).getPropertyValue('left');
        var obj_corner_house_left_int = parseInt(obj_corner_house_left_string); //Marge esquerre de l'objecte (int)
        var obj_corner_house_width_string = window.getComputedStyle(corner_house, null).getPropertyValue('width');
        var obj_corner_house_width_int = parseInt(obj_corner_house_width_string);
        var obj_corner_house_right_int = obj_corner_house_left_int + obj_corner_house_width_int; //Marge dret de l'objecte (int)
        var obj_corner_house_top_string = window.getComputedStyle(corner_house, null).getPropertyValue('top');
        var obj_corner_house_top_int = parseInt(obj_corner_house_top_string); //Marge superior de l'objecte (int)
        var obj_corner_house_height_string = window.getComputedStyle(corner_house, null).getPropertyValue('height');
        var obj_corner_house_height_int = parseInt(obj_corner_house_height_string); 
        var obj_corner_house_bottom_int = obj_corner_house_top_int + obj_corner_house_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "corner_house" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_corner_house_left_int && pj_left_int < obj_corner_house_right_int && pj_top_int + pj_height_int > obj_corner_house_top_int && pj_top_int < obj_corner_house_bottom_int){
                    pj_left_int = obj_corner_house_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "corner_house" per l'esquerra
                if (pj_left_int - speed < obj_corner_house_right_int && pj_left_int + pj_width_int > obj_corner_house_left_int && pj_top_int + pj_height_int > obj_corner_house_top_int && pj_top_int < obj_corner_house_bottom_int){
                    pj_left_int = obj_corner_house_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "corner_house" per sota
                if (pj_top_int - speed < obj_corner_house_bottom_int && pj_left_int < obj_corner_house_right_int && pj_left_int + pj_width_int > obj_corner_house_left_int && pj_top_int + pj_height_int > obj_corner_house_top_int){
                    pj_top_int = obj_corner_house_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "corner_house" per dalt
                if (pj_top_int + pj_height_int + speed > obj_corner_house_top_int && pj_left_int < obj_corner_house_right_int && pj_left_int + pj_width_int > obj_corner_house_left_int && pj_top_int + pj_height_int < obj_corner_house_bottom_int){
                    pj_top_int = obj_corner_house_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "corner_house" -----------------------------------------------

    //Controlar colisio amb objectes  "fountain" ----------------------------------------
    var obj_fountain = document.querySelectorAll('.fountain');
   
    obj_fountain.forEach(function(fountain){ 
        var obj_fountain_left_string = window.getComputedStyle(fountain, null).getPropertyValue('left');
        var obj_fountain_left_int = parseInt(obj_fountain_left_string); //Marge esquerre de l'objecte (int)
        var obj_fountain_width_string = window.getComputedStyle(fountain, null).getPropertyValue('width');
        var obj_fountain_width_int = parseInt(obj_fountain_width_string);
        var obj_fountain_right_int = obj_fountain_left_int + obj_fountain_width_int; //Marge dret de l'objecte (int)
        var obj_fountain_top_string = window.getComputedStyle(fountain, null).getPropertyValue('top');
        var obj_fountain_top_int = parseInt(obj_fountain_top_string); //Marge superior de l'objecte (int)
        var obj_fountain_height_string = window.getComputedStyle(fountain, null).getPropertyValue('height');
        var obj_fountain_height_int = parseInt(obj_fountain_height_string); 
        var obj_fountain_bottom_int = obj_fountain_top_int + obj_fountain_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "fountain" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_fountain_left_int && pj_left_int < obj_fountain_right_int && pj_top_int + pj_height_int > obj_fountain_top_int && pj_top_int < obj_fountain_bottom_int){
                    pj_left_int = obj_fountain_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "fountain" per l'esquerra
                if (pj_left_int - speed < obj_fountain_right_int && pj_left_int + pj_width_int > obj_fountain_left_int && pj_top_int + pj_height_int > obj_fountain_top_int && pj_top_int < obj_fountain_bottom_int){
                    pj_left_int = obj_fountain_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "fountain" per sota
                if (pj_top_int - speed < obj_fountain_bottom_int && pj_left_int < obj_fountain_right_int && pj_left_int + pj_width_int > obj_fountain_left_int && pj_top_int + pj_height_int > obj_fountain_top_int){
                    pj_top_int = obj_fountain_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "fountain" per dalt
                if (pj_top_int + pj_height_int + speed > obj_fountain_top_int && pj_left_int < obj_fountain_right_int && pj_left_int + pj_width_int > obj_fountain_left_int && pj_top_int + pj_height_int < obj_fountain_bottom_int){
                    pj_top_int = obj_fountain_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "fountain" -----------------------------------------------

    //Controlar colisio amb objectes  "tree" ----------------------------------------
    var obj_tree = document.querySelectorAll('.tree');
   
    obj_tree.forEach(function(tree){ 
        var obj_tree_left_string = window.getComputedStyle(tree, null).getPropertyValue('left');
        var obj_tree_left_int = parseInt(obj_tree_left_string); //Marge esquerre de l'objecte (int)
        var obj_tree_width_string = window.getComputedStyle(tree, null).getPropertyValue('width');
        var obj_tree_width_int = parseInt(obj_tree_width_string);
        var obj_tree_right_int = obj_tree_left_int + obj_tree_width_int; //Marge dret de l'objecte (int)
        var obj_tree_top_string = window.getComputedStyle(tree, null).getPropertyValue('top');
        var obj_tree_top_int = parseInt(obj_tree_top_string); //Marge superior de l'objecte (int)
        var obj_tree_height_string = window.getComputedStyle(tree, null).getPropertyValue('height');
        var obj_tree_height_int = parseInt(obj_tree_height_string); 
        var obj_tree_bottom_int = obj_tree_top_int + obj_tree_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "tree" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_tree_left_int && pj_left_int < obj_tree_right_int && pj_top_int + pj_height_int > obj_tree_top_int && pj_top_int < obj_tree_bottom_int){
                    pj_left_int = obj_tree_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "tree" per l'esquerra
                if (pj_left_int - speed < obj_tree_right_int && pj_left_int + pj_width_int > obj_tree_left_int && pj_top_int + pj_height_int > obj_tree_top_int && pj_top_int < obj_tree_bottom_int){
                    pj_left_int = obj_tree_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "tree" per sota
                if (pj_top_int - speed < obj_tree_bottom_int && pj_left_int < obj_tree_right_int && pj_left_int + pj_width_int > obj_tree_left_int && pj_top_int + pj_height_int > obj_tree_top_int){
                    pj_top_int = obj_tree_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "tree" per dalt
                if (pj_top_int + pj_height_int + speed > obj_tree_top_int && pj_left_int < obj_tree_right_int && pj_left_int + pj_width_int > obj_tree_left_int && pj_top_int + pj_height_int < obj_tree_bottom_int){
                    pj_top_int = obj_tree_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "tree" -----------------------------------------------

    //Controlar colisio amb objectes  "truck" ----------------------------------------
    var obj_truck = document.querySelectorAll('.truck');
   
    obj_truck.forEach(function(truck){ 
        var obj_truck_left_string = window.getComputedStyle(truck, null).getPropertyValue('left');
        var obj_truck_left_int = parseInt(obj_truck_left_string); //Marge esquerre de l'objecte (int)
        var obj_truck_width_string = window.getComputedStyle(truck, null).getPropertyValue('width');
        var obj_truck_width_int = parseInt(obj_truck_width_string);
        var obj_truck_right_int = obj_truck_left_int + obj_truck_width_int; //Marge dret de l'objecte (int)
        var obj_truck_top_string = window.getComputedStyle(truck, null).getPropertyValue('top');
        var obj_truck_top_int = parseInt(obj_truck_top_string); //Marge superior de l'objecte (int)
        var obj_truck_height_string = window.getComputedStyle(truck, null).getPropertyValue('height');
        var obj_truck_height_int = parseInt(obj_truck_height_string); 
        var obj_truck_bottom_int = obj_truck_top_int + obj_truck_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "truck" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_truck_left_int && pj_left_int < obj_truck_right_int && pj_top_int + pj_height_int > obj_truck_top_int && pj_top_int < obj_truck_bottom_int){
                    pj_left_int = obj_truck_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "truck" per l'esquerra
                if (pj_left_int - speed < obj_truck_right_int && pj_left_int + pj_width_int > obj_truck_left_int && pj_top_int + pj_height_int > obj_truck_top_int && pj_top_int < obj_truck_bottom_int){
                    pj_left_int = obj_truck_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "truck" per sota
                if (pj_top_int - speed < obj_truck_bottom_int && pj_left_int < obj_truck_right_int && pj_left_int + pj_width_int > obj_truck_left_int && pj_top_int + pj_height_int > obj_truck_top_int){
                    pj_top_int = obj_truck_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "truck" per dalt
                if (pj_top_int + pj_height_int + speed > obj_truck_top_int && pj_left_int < obj_truck_right_int && pj_left_int + pj_width_int > obj_truck_left_int && pj_top_int + pj_height_int < obj_truck_bottom_int){
                    pj_top_int = obj_truck_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "truck" -----------------------------------------------

    //Controlar colisio amb objectes  "high_house" ----------------------------------------
    var obj_high_house = document.querySelectorAll('.high_house');

    obj_high_house.forEach(function(high_house){ 
        var obj_high_house_left_string = window.getComputedStyle(high_house, null).getPropertyValue('left');
        var obj_high_house_left_int = parseInt(obj_high_house_left_string); //Marge esquerre de l'objecte (int)
        var obj_high_house_width_string = window.getComputedStyle(high_house, null).getPropertyValue('width');
        var obj_high_house_width_int = parseInt(obj_high_house_width_string);
        var obj_high_house_right_int = obj_high_house_left_int + obj_high_house_width_int; //Marge dret de l'objecte (int)
        var obj_high_house_top_string = window.getComputedStyle(high_house, null).getPropertyValue('top');
        var obj_high_house_top_int = parseInt(obj_high_house_top_string); //Marge superior de l'objecte (int)
        var obj_high_house_height_string = window.getComputedStyle(high_house, null).getPropertyValue('height');
        var obj_high_house_height_int = parseInt(obj_high_house_height_string); 
        var obj_high_house_bottom_int = obj_high_house_top_int + obj_high_house_height_int;//Marge inferior de l'objecte (int)


        if(key.keyCode == arrow_right){ //Colisio amb objecte "high_house" per la dreta
                if (pj_left_int + pj_width_int + speed > obj_high_house_left_int && pj_left_int < obj_high_house_right_int && pj_top_int + pj_height_int > obj_high_house_top_int && pj_top_int < obj_high_house_bottom_int){
                    pj_left_int = obj_high_house_left_int - pj_width_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_left){ //Colisio amb objecte "high_house" per l'esquerra
                if (pj_left_int - speed < obj_high_house_right_int && pj_left_int + pj_width_int > obj_high_house_left_int && pj_top_int + pj_height_int > obj_high_house_top_int && pj_top_int < obj_high_house_bottom_int){
                    pj_left_int = obj_high_house_right_int;
                    speedx = 0;
            }
        }
        if(key.keyCode == arrow_top){ //Colisio amb objecte "high_house" per sota
                if (pj_top_int - speed < obj_high_house_bottom_int && pj_left_int < obj_high_house_right_int && pj_left_int + pj_width_int > obj_high_house_left_int && pj_top_int + pj_height_int > obj_high_house_top_int){
                    pj_top_int = obj_high_house_bottom_int;
                    speedy = 0;
                }
        }
        if(key.keyCode == arrow_bottom){ //Colisio amb objecte "high_house" per dalt
                if (pj_top_int + pj_height_int + speed > obj_high_house_top_int && pj_left_int < obj_high_house_right_int && pj_left_int + pj_width_int > obj_high_house_left_int && pj_top_int + pj_height_int < obj_high_house_bottom_int){
                    pj_top_int = obj_high_house_top_int - pj_height_int;
                    speedy = 0;
                }
        }
    }); 
    //Fi colisio amb objecte "high_house" -----------------------------------------------

    //Aplicar moviment
    pj_left_int = pj_left_int + speedx;
    pj_top_int = pj_top_int + speedy;

    //Conversió de num a string 
    pj.style.left = pj_left_int + "px";
    pj.style.top = pj_top_int + "px";


});


}

/* Millores si temps:
Crear una sola funció per a totes les comparacions de colisio
Pj amb moviment

*/