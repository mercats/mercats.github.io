<?php
    session_start();
    require_once("./php_librarys/bd.php");
    $usuarios =  selectUsuarioId($_SESSION['id_usuario']); 
    $usuario_has_mercados = selectUsuarioHasMercados();
    $usuario_has_ofertas = selectUsuarioHasOfertasId($_SESSION['id_usuario']);
    $mercados = selectMercados();
    $ofertas = selectAllOfertas();
    ?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mercats BCN</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
        <link rel="stylesheet" href="./styles/styles_propios_perfil.css">
        
    </head>
    <body>
        <div class="main_body">
            <header>
                <form action="./php_controllers/proyecto_control.php" method="post" enctype="multipart/form-data">
                    <nav class="navbar navbar-expand-lg navbar-dark bg-dark main_navbar">
                        <a class="navbar-brand" href="main.php">Mercados de Barcelona</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div id="idiomas">
                            <div  class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                                <a href="perfil.php" id="primeridioma">
                                    <img src="./images/catala.png" width="40" height="20" alt="Catalán">   
                                </a>
                                <a href="perfil_en.php">
                                    <img src="./images/angles.png" width="40" height="20" alt="Inglés">  
                                </a>
                            </div>
                        </div>
                    
                        <div class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <?php foreach($usuarios as $usuario){ echo $usuario["nombre"];} ?>
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="left:-70px">
                                        <button type="submit" name="Perfil" class="btn btn-link dropdown-item">Perfil</button>
                                        <button type="submit" name="cerrarSesion" class="btn btn-link dropdown-item">Cerrar Sesión</button>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </form>
            </header>
            <footer>
                <main>

                    <div class="container justify-content-center">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card p-3 py-1 mt-3">
                                    <div class="card-header">
                                        <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Detalles del usuario</h3> 
                                    </div>
                                    <div class="card-body">
                                        <h4 class="card-title">Nombre: <?php foreach($usuarios as $usuario){echo $usuario["nombre"]; }?></h4>
                                        <h4 class="card-text">Correo Electronico: <?php foreach($usuarios as $usuario){echo $usuario["correo"]; }?></h4>
                                        <h4 class="card-text">Puntos: <?php foreach($usuarios as $usuario){echo $usuario["puntos"]; }?></h4>
                                        <button type="button" class="btn btn-dark botonEdit" data-id="<?php foreach($usuarios as $usuario){echo $usuario["id_usuario"]; }?>" data-nombre="<?php foreach($usuarios as $usuario){echo $usuario["nombre"];}?>"  data-correo="<?php foreach($usuarios as $usuario){echo $usuario["correo"];}?>" data-contrasena="<?php foreach($usuarios as $usuario){echo $usuario["contrasena"];}?>" data-puntos="<?php foreach($usuarios as $usuario){echo $usuario["puntos"];}?>" data-toggle="modal" data-target="#modalFunction">Editar campos</button> 
                                        <button type="submit" class="btn btn-dark botonEliminar"style="margin: 10px;" data-toggle= "modal" data-target="#modalEliminar">Eliminar usuario</button>
                                        <?php foreach($usuarios as $usuario){
                                            if($usuario["administrador"] == 1){?>
                                                <a href="./crear_oferta_es.php" class="btn btn-dark botonCrearOferta" style="margin: 10px; float: right;">Crear oferta</a>
                                           <?php }
                                         }?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row justify-content-around divAbajo">
                        <?php include_once('php_partials/mensaje.php')?>
                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Tus Mercados</h3> 
                                    </div>
                                    <div class="card-body">
                                        <select class="custom-select" multiple>
                                            <?php foreach($mercados as $mercado){ 
                                                foreach($usuario_has_mercados as $usuario_has_mercado){
                                                    if($usuario_has_mercado['id_mercado'] == $mercado['id_mercado']){
                                                        if($usuario_has_mercado['id_usuario'] == $_SESSION['id_usuario']){?>
                                                        <option disabled><?php echo $mercado["nombre"]?> </option>
                                                    <?php }
                                                    }
                                                } 
                                             }?>
                                        </select>
                                        <br>
                                        <a href="#" class="btn btn-dark botonEdit">Editar campos</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5 ">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="h1_mercats w3-animate-opacity" style= "text-align: center;">Tus Ofertas</h3> 
                                            </div>
                                            
                                    <div>
                                        <div class="card-body overflow-auto divTable">
                                            <table class = "table">
                                                <tr>
                                                    <td>Mercado</td>
                                                    <td>Tipo de comercio</td>
                                                    <td>Puntos</td>
                                                    <td>Descripción</td>
                                                </tr>
                                                <?php 
                                                foreach($ofertas as $oferta){ 
                                                    foreach($usuario_has_ofertas as $usuario_has_oferta){
                                                        if($oferta["id_oferta"]==$usuario_has_oferta["id_oferta"]){?>
                                                            <tr>
                                                                <?php foreach($mercados as $mercado){
                                                                    if($mercado["id_mercado"] == $oferta["id_mercado"]){?>
                                                                        <td><?php echo $mercado['nombre']?></td>
                                                                    <?php }
                                                                }?>
                                                                <td><?php echo $oferta['tipo_negocio']?></td>
                                                                <td><?php echo $oferta['coste_puntos']?></td>
                                                                <td><?php echo $oferta['descripcion']?></td>
                                                            </tr>
                                                        <?php }
                                                    } 
                                                }?>
                                            </table>                 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </main>
            </footer>
        </div>
    </body>
    <div class="modal fade" id="modalFunction" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel" style= "text-align: center;">Editar Campos</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="./php_controllers/proyecto_control.php" method="POST" enctype="multipart/form-data">
        <div class="modal-body">
            <div class="form-group nombre">
                <label for="recipient-name" class="col-form-label">Nombre:</label>
                <input type="text" class="form-control" name="nombre" id="Nombre" value= "<?php foreach($usuarios as $usuario){echo $usuario["nombre"];}?>">
            </div>
            <div class="form-group">
                <label for="message-text" class="col-form-label">Contraseña:</label>
                <input type="password" class="form-control" name="contrasena" id="Contrasena" value="<?php foreach($usuarios as $usuario){echo $usuario["contrasena"];}?>">
            </div>
            <div class="form-group">
                <label for="message-text" class="col-form-label">Correo:</label>
                <input type="text" class="form-control"name="correo" id="Correo" value="<?php foreach($usuarios as $usuario){echo $usuario["correo"];}?>">
            </div>
            <?php foreach($usuarios as $usuario){
                if($usuario['administrador'] == 1){?>
                     <div class="form-group">
                        <label for="message-text" class="col-form-label">Puntos:</label>
                        <input type="number" class="form-control" name="puntos" id="Puntos" value="<?php foreach($usuarios as $usuario){echo $usuario["puntos"];}?>">
                    </div>
               <?php }
               }?>

           
        </div>
        <input type="hidden" name ="lang" value="ofertas_cat">
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <?php foreach($usuarios as $usuario){
                if($usuario['administrador'] == 1){?>
            <button type="submit" class="btn btn-dark" name="cambiarDatosAdmin">Guardar</button>
            <?php }
            else{?>
                <button type="submit" class="btn btn-dark" name="cambiarDatos">Guardar</button>
            <?php }
               }?>
            <input type="hidden" class="form-control" id="inputIdUsuario" name="inputIdUsuario" value="<?php foreach($usuarios as $usuario){echo $usuario["id_usuario"];}?>">
            <input type="hidden" class="form-control"  name="lang" value="perfil_cat">

     </form>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="modalEliminar" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="./php_controllers/proyecto_control.php" method="POST" enctype="multipart/form-data">
            <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="staticBackdropLabel" style= "text-align: center;">Eliminar usuario</h3>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ¿Seguro que quiere eliminar este usuario?
                Una vez hecho no se podrá recuperar.
                <input type="hidden" name ="lang" value="main_es">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                
                    <button href="#" class="btn btn-outline-primary" type= "submit" name="eliminarUsuari"> Sí </button>
                    <input type="hidden" name ="id_usuario" value="<?php foreach($usuarios as $usuario){ echo $usuario["id_usuario"];} ?>">

            </div>
            </div>
        </form>
    </div>
</div>
<script>
    $('#modalFunction').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var id_usuario = button.data('id')// Extract info from data-* attributes
  var nombre = button.data('nombre')
  var contrasena = button.data('contrasena')
  var correo = button.data('correo')
  var puntos = button.data('puntos')

  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-footer #inputIdUsuario').val(id_usuario)
  modal.find('.modal-body #Nombre').val(nombre)
})
</script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>










