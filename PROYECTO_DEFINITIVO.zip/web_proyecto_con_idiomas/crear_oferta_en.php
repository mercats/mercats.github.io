<?php
    session_start();
    require_once("./php_librarys/bd.php");
    $usuarios =  selectUsuarioId($_SESSION['id_usuario']); 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercats BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="./styles/styles_propios_crear_oferta.css">
</head>
<body>
    <div class="main_body">
        <header>
            <form action="./php_controllers/proyecto_control.php" method="post" enctype="multipart/form-data">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark main_navbar">
                    <a class="navbar-brand" href="main_en.php">Barcelona Markets</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div id="idiomas">
                        <div  class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                            <a href="crear_oferta.php" id="primeridioma">
                                <img src="./images/catala.png" width="40" height="20" alt="Catala">   
                            </a>
                            <a href="crear_oferta_es.php">
                                <img src="./images/castella.png" width="40" height="20" alt="Castella">  
                            </a>
                        </div>
                    </div>
                    <span class="navbar-text" style="position: absolute; display: flex; margin-left: 80%;">
                        Accumulated points: <?php foreach($usuarios as $usuario){ echo $usuario["puntos"];} ?>
                    </span>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php foreach($usuarios as $usuario){ echo $usuario["nombre"];} ?>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <button type="submit" name="Perfil" class="btn btn-link dropdown-item">Profile</button>
                                    <button type="submit" name="cerrarSesion" class="btn btn-link dropdown-item">Log Out</button>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </form>
        </header>

        <main>
        <form action="./php_controllers/proyecto_control.php" method="post" enctype="multipart/form-data">
        <?php include_once('php_partials/mensaje.php')?>
            <div class="container justify-content-center">
                <div class="row justify-content-around">
                    <div class="col-md-6">
                        <div class="card p-3 py-1 mt-3">
                            <div class="card-header">
                                <h3 class="h1_mercats w3-animate-opacity">Create offer</h3> 
                            </div>
                            <div class="card-body">
                                <div class="form-group row formulario">
                                    <label for="tipus" class="col-sm-4 col-form-label">Business type:</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" name="tipoMercado" id="tipus" placeholder="Fruit market, fish market..." required>
                                    </div>
                                </div>
                                <div class="form-group row formulario">
                                    <label for="cost" class="col-sm-4 col-form-label">Cost in points:</label>
                                    <div class="col-sm-6">
                                        <input type="number" class="form-control" name="costePuntos" id="cost" placeholder="Cost" required>
                                    </div>
                                </div>
                                <div class="form-group row formulario">
                                    <label for="descripcio" class="col-sm-4 col-form-label">Description:</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" name="descripcion" id="descripcio" placeholder="A little description" required>
                                    </div>
                                </div>
                            
                                <div class="form-group row formulario">
                                    <label for="mercat" class="col-sm-4 col-form-label">Select a market:</label>
                                    <div class="col-sm-6">
                                    <select name="id_mercado" class="form-select mercado" aria-label="Default select example">
                                            <option disabled selected>Select a market</option>
                                            <?php foreach($mercados as $mercado){?>
                                                <option  value=<?php echo $mercado['id_mercado']?> ><?php echo $mercado['nombre']?> </option>
                                             <?php }?>
                                        </select>
                                    </div>
                                </div>
                                <a href="./perfil_en.php" class="btn btn-dark botonEdit">Cancel</a>
                                <button type="submit" name="crearOferta"class="btn btn-dark botonEdit">Create</button>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name ="lang" value="perfil_en">
            </div>
        </form>
        </main>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>