<?php 
    session_start();
    require_once("../php_librarys/bd.php");
    $usuarios =  selectUsuarioId($_SESSION['id_usuario']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercados BCN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="./styles/(materia)bootstrap.min.css">
    <link rel="stylesheet" href="./styles/styles_propios.css">
    <link rel="stylesheet" href="./styles/divs_juego.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="funciones_juego.js" language="javascript" type="text/javascript"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body id="body">
    <header>
        <form action="../php_controllers/proyecto_control.php" method="post" enctype="multipart/form-data">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark main_navbar">
                <a class="navbar-brand" href="../main_es.php">Mercados de Barcelona</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div id="idiomas" style="margin-left: 10%;">
                    <div  class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                        <a href="./index.php" id="primeridioma">
                            <img src="../images/catala.png" width="40" height="20" alt="Català">   
                        </a>
                        <a href="../index_en.php">
                            <img src="../images/angles.png" width="40" height="20" alt="Angles">  
                        </a>
                    </div>
                </div>
            
                <div class="buttons_nav" style="position: absolute; display: flex; margin-left: 55%;">
                    <div class="button_ofertes" style="margin-right: 15%;">
                        <a href="../ofertes_es.php">
                            <img src="../images/Offers_button.png" width="30" height="30" style="border-radius: 50%;">
                        </a>
                    </div>

                    <div class="button_jocs" style="margin-right: 15%;">
                        <a href="../jocs_es.php">
                            <img src="../images/Game_button.png" width="30" height="30" style="border-radius: 50%;">
                        </a>
                    </div>

                    <div class="button_mercats" style="margin-right: 15%;">
                        <a href="../mercats_bcn_es.php">
                            <img src="../images/Market_button.png" width="30" height="30" style="border-radius: 50%;">
                        </a>
                    </div>

                    <div class="button_qui_som">
                        <a href="../qui_som_es.php">
                            <img src="../images/People_button.png" width="30" height="30" style="border-radius: 50%;">
                        </a>
                    </div>

                </div>
                <span class="navbar-text" style="position: absolute; display: flex; margin-left: 75%;">
                Puntos acumulados: <?php foreach($usuarios as $usuario){ echo $usuario["puntos"];} ?>
            </span>
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent" id="navbarColor01">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php foreach($usuarios as $usuario){ echo $usuario["nombre"];} ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="left:-70px">
                                <button type="button" name="Perfil" class="btn btn-link dropdown-item"><a href="../perfil_es.php">Perfil</a></button>
                                <button type="submit" name="cerrarSesion" class="btn btn-link dropdown-item">Cerrar Sesión</button>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </form>
    </header>
    <main>
    <form action="../php_controllers/proyecto_control.php" method="POST" enctype="multipart/form-data">

        <div class="container">
            <?php include_once('../php_partials/mensaje.php')?>
            <div id="principal">
            <button type= "button" id="botonInicio">Iniciar</button>
            <button type= submit name="botonGuardarPuntuacion" id="botonReinicioYGuardar" style="visibility: hidden; width: 220px; height: 60px; top: 200px; left: 250px; margin: auto;  text-align: center; position: absolute; font-family: '8-bit'; border-radius: 5%;">Guardar puntuacion</button>
            <div id="cuentaAtras">3</div>
            <div id="camion"></div>
            <div id="contador"></div>
            <div id="bloque1" class="bloque"></div>
            <div id="bloque2" class="bloque"></div>
            <div id="bloque3" class="bloque"></div>
            <div id="indicadorVidas1" class= "indicadorVidas"></div>
            <div id="indicadorVidas2" class= "indicadorVidas"></div>
            <div id="indicadorVidas3" class= "indicadorVidas"></div>
            <div id="indicadorEscudo"></div>
            <div id="vidas"></div>
            <div id="escudo"></div>
            <div id="meta"></div>
            <div id="boom"></div>
            <div id="leyenda">
                <div id="flechasLeyenda"></div>
                <div id="flechasTexto">Controles</div>
                <div id="corazonLeyenda"></div>
                <div id="corazonTexto">Vida</div>
                <div id="escudoLeyenda"></div>
                <div id="escudoTexto">Escudo(Duracion:5s)</div>
                <div id="cocheLeyenda"></div>
                <div id="cocheTexto">Coches</div>
                <div id="camionLeyenda"></div>
                <div id="camionTexto">Camion</div>
                <button type= "button" id="botonMensaje">Mostrar Mensaje Inicial</button>
            </div>
            </div>
            
            <input type="hidden" name ="lang" value="juego2_es">
        </div> 
    </form>
    </main>
   
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</html>