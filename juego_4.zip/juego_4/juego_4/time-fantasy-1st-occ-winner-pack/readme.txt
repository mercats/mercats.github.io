Jason Perry, the creator of Time Fantasy, presents a very special surprise gift for all RPG Makers out there with a new, free DLC!

Thanks to Jason�fs generous gesture for this contest�fs winners, the 11 most popular voted characters in the �gOriginal Character Contest�h have all been recreated in Time fantasy style to be released in this free DLC pack!

Included are walking sprites.
Formatted for use in MV, VX ace XP 2000. What a treat!

So why not create your own Time Fantasy world with these memorable and awarded characters from the first ever OCC!

---------------------------------------------

Jason Perry (Twitter link icon here)
Pro pixel artist / Indie game dev. / Creator of RPG assets.

---------------------------------------------

Time Fantasy
http://www.rpgmakerweb.com/a/rpg-maker-vxace-character/time-fantasy

Time Fantasy: Monsters
http://www.rpgmakerweb.com/a/rpg-maker-mv-battle/time-fantasy-monsters

Time Fantasy: Winter Tiles
http://www.rpgmakerweb.com/a/rpg-maker-mv-tileset/time-fantasy-winter-tiles

Time Fantasy Add-on: Animals
http://www.rpgmakerweb.com/a/rpg-maker-mv-character/time-fantasy-add-on-animals

Time Fantasy Add-on: Dwarves Vs Elves
http://www.rpgmakerweb.com/a/rpg-maker-mv-character/time-fantasy-add-on-dwarves-vs-elves

Time Fantasy: Farm and Fort
http://www.rpgmakerweb.com/a/rpg-maker-mv-tileset/time-fantasy-farm-and-fort

Time Fantasy: Ship
http://www.rpgmakerweb.com/a/rpg-maker-vxace-tileset/time-fantasy-ship

Time Fantasy: Side-view Animated Battlers
http://www.rpgmakerweb.com/a/rpg-maker-mv-character/time-fantasy-side-view-animated-battlers

---------------------------------------------

What is the Original Character Contest?

To celebrate the 1st year anniversary of the RPG Maker forum in Japan, we held an event for the first time, the �gOriginal Character Contest.�h You can read about it here:

Original Character Contest: Link
https://forums.rpgmakerweb.com/index.php?threads/original-character-contest-winners.94745/
https://forums.rpgmakerweb.com/index.php?threads/original-character-contest.93895/