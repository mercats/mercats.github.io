window.onload = function(){
    swal('Benvingut!',"Tindràs els controls a l'esquerra del joc.\n\nEl següent objetiu estarà marcat a la dreta del joc.\n\nPer cada repte complert se't afegiran 50 punts.\n\nBona Sort.");
    var container = document.getElementById('container');
    var start = document.getElementById('start');
    var cliente1 = document.getElementById('cliente1');
    var indicador1 = document.getElementById('indicador1');
    var valla = document.getElementById('valla');
    var cliente2 = document.getElementById('cliente2');
    var indicador2 = document.getElementById('indicador2');
    var cuenta_atras = document.getElementById('cuenta_atras');
    var arbol = document.getElementById('arbol');
    var casa = document.getElementById('casa');
    var papa_noel = document.getElementById('papa_noel');
    var puerta = document.getElementById('puerta');
    var regalos = document.getElementById('regalos');
    var reno = document.getElementById('reno');
    var dueña = document.getElementById('dueña');
    var caja = document.getElementById('caja');
    var cereales = document.getElementById('cereales');
    var puesto_frutas_1 = document.getElementById('puesto_frutas_1');
    var puesto_frutas_2 = document.getElementById('puesto_frutas_2');
    var puesto_frutas_3 = document.getElementById('puesto_frutas_3');
    var puesto_frutas_4 = document.getElementById('puesto_frutas_4');
    var congelador = document.getElementById('congelador');
    var muro_comida = document.getElementById('muro_comida');
    var llave_id = document.getElementById('llave');
    var indicador3 = document.getElementById('indicador3');
    var boton = document.getElementById('boton');
    var nieve = document.getElementById('container_nieve');
    var audio = document.getElementById('audio');
    var nombre_dueña = document.getElementById('nombre_dueña');
    var siguiente_objetivo = document.getElementById('siguiente_objetivo');
    var sumar = document.getElementById('sumar');
            
    var puntos = 0;
    var start_on = false;
    var primera_charla = false;
    var platano = false;
    var platano_hecho = false;
    var cliente1_on = false;
    var naranjas = false;
    var naranjas_hecho = false;
    var cliente1_completado = false;
    var cliente2_on = false
    var cereales_on = false;
    var llave = false;
    var llave_cogida = false;
    var cliente2_completado = false;
    var cliente3 = false;
    var total = 0;
    var cliente2_error = false;
    var cambio_fondo = false;
    var papa_noel_on = false;
    var cambio_fondo2 = false;
    var detergente = false;
    var cambio_fondo3 = false;
    var papa_noel_completado = false;
    var juego_completado = false;

    var izquierda = 37;
    var arriba = 38;
    var derecha = 39;
    var abajo = 40;


    start.addEventListener("click", function(){ 
        if(start_on == false){
            swal('A jugar!',"Com t'hauràs fixat estàs a un mercat gegant.\n\nTindràs que ajudar a la propietària (Rosa) a donar els productes indicats als clients.\n\nElla et donarà la teva recompensa.\n\nParla amb ella i presenta't.");
            start.style.visibility = "hidden";
            start_on = true;
            audio.play();
            audio.style.visibility = "visible";
            siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "110" + "px";
        }
    })

    boton.onclick = function boton(){
        if(start_on == false){
            swal('Benvingut!',"Tindràs els controls a l'esquerra del joc.\n\nEl següent objetiu estarà marcat a la dreta del joc.\n\nPer cada repte complert se't afegiran 50 punts.\n\nBona Sort.");
        }
        else if(start_on == true && primera_charla == false){
            swal('A jugar!',"Com t'hauràs fixat estàs a un mercat gegant.\n\nTindràs que ajudar a la propietària (Rosa) a donar els productes indicats als clients.\n\nElla et donarà la teva recompensa.\n\nParla amb ella i presenta't.");
        }
        else if(primera_charla == true && platano == false){
            swal('Hola!',"Rosa: Encantada, soc la propietària d'aquest mercat.\n\nNecessitaré que entreguis el producte que vol cada client.\n\nAnem a fer una prova, porta-me'n un plàtan de la parada de fruita.");
        }
        else if(platano == true && platano_hecho == false){
            swal('Has agafat un plàtan!','Porta-li a Rosa');
        }
        else if(platano_hecho == true && cliente1_on == false){
            swal('Molt bé!',"Rosa: Ara parla amb el client 1 a veure quin producte desitga.\n\nSe t'han afegit 50 punts.",'success');
        }
        else if(cliente1_on == true && naranjas == false){
            swal('Hola, com va tot?','Client 1: Jo soc en Ramón, i he vingut al mercat perque necessito 1kg de taronges.\n\nPodries ajudarme?');
        }
        else if(naranjas == true && naranjas_hecho == false){
            swal('Has agafat 1kg de taronges','Porta el producte al client 1');
        }
        else if(naranjas_hecho == true && cliente1_completado == false && cliente1.style.visibility != "hidden"){
            swal('Moltes gracies!','Client 1: Ara jà podré fer-me els meus sucs.\n\nFins aviat.');
        }
        else if(cliente1_completado == true && cliente2_on == false){
            swal('Ho has conseguit!',"Rosa: Ho estàs fent molt bè, però anem a veure si es suficient.\n\nBusca al client 2 a veure quin producte desitga.\n\nSe t'han afegit 50 punts.",'success');
        }
        else if(cliente2_on == true && cereales_on == false){
            swal('Hola!','Client 2: Necessito que em portis cereals.\n\nCrec que eren uns amb caixa verda.\n\nAjudam a trobarlos, siusplau.');
        }
        else if(cereales_on == true && llave == false && llave_id.style.visibility != "visible"){
            swal('Has agafat una caixa de cereals!','Porta el producte al client 2');
        }
        else if(cereales_on == true && llave == false && llave_id.style.visibility == "visible"){
            swal('Oh no!','Ha aparegut una porta i no podem donar el producte al client.\n\Parla amb Rosa a veure que podem fer.','warning');
        }
        else if(llave == true && llave_cogida == false && cliente2_error == false){
            swal('Que???',"Rosa: Aixó si que no m'ho ho esperava, feia molt de temps que no apareixia la porta.\n\nTinc una clau, però no se on la he posat.\n\nAjudam a buscarla rápid, només tenim 30 segons abans que el client marxi.");
        }
        else if(llave == true && llave_cogida == false && cliente2_error == true && cliente2_completado == false && cliente3 == false){
            swal('Has fallat!','El client ha marxat.\n\nParla amb Rosa.','danger');
        }
        else if(llave == true && llave_cogida == true && cliente2_error == false && cliente2_completado == false && cliente3 == false){
            swal('Has trobat la clau!','Porta el producte al client');
        }
        else if(llave == true && llave_cogida == true && cliente2_error == true && cliente2_completado == false && cliente3 == false){
            swal('Has trobat la clau!','Però és massa tard, el client ja ha marxat.\n\nParla amb Rosa.');
        }
        else if(cliente2_error == false && llave_cogida == true && cliente2_completado == true && cliente2.style.visibility != "hidden" && cliente3 == false){
            swal('Graciés!','Client 2: Has pogut obrir la porta, estava molt espantada.\n\nQue vagi bé.');
        }
        else if(cliente2_completado == true && cliente2_error == false && cliente3 == true && papa_noel_on == false){
            swal('Ho has conseguit!',"Rosa: Ho estàs fent molt bé, però anem a veure si es suficiente.\n\nBusca al client 3, no el veig per aquí, a veure que desitga.\n\nSe t'han afegit 50 punts.",'success');
        }
        else if(cliente2_error == true && cliente3 == true && papa_noel_on == false){
            swal('Oh no!','Rosa: El client 2 ha marxat, no et podré recompensar.\n\nIntenta que no torni a passar.\n\nBusca al client 3, no el veig per aquí, a veure que desitga.','danger');
        }
        else if(cambio_fondo == true && papa_noel_on == true && detergente == false){
            swal('Hola!',"Papa Noel: Benvigut a Rovaniemi, Finlandia.\n\nImagino que t'ha enviat la Rosa. He anat a la botiga a comprar detergent però he vist que hi havia gent esperant així que li he dit a Rosa que m'ho porti.\n\nPodries anar a buscarlos?\n\nSi no estic equivocat la caixa era de color vermell.");
        }
        else if(cambio_fondo2 == true && detergente == true && papa_noel_completado == false){
            swal('Has agafat una caixa de detergent!','Porta-li a Papa Noel');
        }
        else if(juego_completado == true){
            swal('Ho has conseguit!',"Rosa: T'ho agraeixo molt, sense tu no hagues sigut possible.\n\nFins una altre.\n\nSe t'han afegit 50 punts.",'success');
        }
    }
    
    document.getElementById('puntuacion').innerHTML = total;

    document.addEventListener('keydown', function(key){
        var personaje_id = document.getElementById('personaje');
        var personaje_style = window.getComputedStyle(personaje_id);
        var personaje_horizontal = personaje_style.getPropertyValue('right');
        var personaje_vertical = personaje_style.getPropertyValue('bottom');

        var horizontal = parseInt(personaje_horizontal);
        var vertical = parseInt(personaje_vertical);

        if(key.keyCode == izquierda){
            personaje_id.style.backgroundPosition = "-45px -113px";
            if(horizontal == 380){
                personaje_id.style.right = horizontal + "px"; //COLISION FINAL IZQUIERDA
            }
            else if(horizontal == 260 && vertical > 180 && puesto_frutas_1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION FRUTAS
            }
            else if(horizontal == 340 && vertical > 320 && cliente1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 1
            }
            else if(horizontal == 120 && vertical < 120 && congelador.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CONGELADOR
            }
            else if(horizontal == 140 && vertical <= 180 && vertical >= 130 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 150 && vertical <= 200 && vertical >= 180 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 160 && vertical <= 230 && vertical >= 210 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 170 && vertical <= 260 && vertical >= 240 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 180 && vertical <= 290 && vertical >= 270 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 330 && vertical == 60 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 250 && vertical <= 60 && vertical >= 30 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 270 && vertical == 20 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(horizontal == 260 && vertical > 310 && vertical < 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 270 && vertical == 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 280 && vertical > 350 && vertical < 370 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 290 && vertical == 370 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(horizontal == 110 && vertical == 290 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else{
                personaje_id.style.right = (horizontal + 10) + "px";
            }
        }
        else if(key.keyCode == arriba){
            personaje_id.style.backgroundPosition = "-45px -42px";
            if(vertical == 370){
                personaje_id.style.bottom = vertical + "px"; //COLISION FINAL ARRIBA
            }
            else if(vertical == 270 && horizontal < 120 && caja.style.visibility != "hidden"){ //COLISION CAJA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 330 && horizontal < 150 && cereales.style.visibility != "hidden"){ //COLISION CEREALES
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 180 && horizontal < 320 && horizontal > 260 && puesto_frutas_1.style.visibility != "hidden"){ //COLISION FRUTAS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 320 && horizontal > 340 && horizontal < 380 && cliente1.style.visibility != "hidden"){ //COLISION CLIENTE 1
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal > 120 && horizontal < 330 && muro_comida.style.visibility != "hidden"){ //COLISION MURO COMIDA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 120 && horizontal > 140 && horizontal < 260 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 20 && horizontal <= 270 && horizontal >= 260 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 10 && horizontal <= 360 && horizontal >= 280 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 310 && horizontal <= 340 && horizontal >= 270 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 270 && horizontal < 100 && casa.style.visibility == "visible"){ //COLISION CASA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 290 && horizontal < 120 && casa.style.visibility == "visible"){ //COLISION CASA
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 280 && horizontal < 160 && horizontal >= 120 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else{
                personaje_id.style.bottom = (vertical + 10) + "px";
            }
        }
        else if(key.keyCode == derecha){
            personaje_id.style.backgroundPosition = "-45px";
            if(horizontal == 0){
                personaje_id.style.right = horizontal + "px"; //COLISION FINAL DERECHA
            }
            else if(horizontal == 120 && vertical > 270 && caja.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CAJA
            }
            else if(horizontal == 150 && vertical > 330 && cereales.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CEREALES
            }
            else if(horizontal == 320 && vertical > 180 && puesto_frutas_1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION FRUTAS
            }
            else if(horizontal == 380 && vertical > 320 && cliente1.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 1
            }
            else if(horizontal == 330 && vertical > 70 && vertical < 120 && muro_comida.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION MURO COMIDA
            }
            else if(horizontal == 190 && vertical < 80 && cliente2.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CLIENTE 2
            }
            else if(horizontal == 160 && vertical < 80 && congelador.style.visibility != "hidden"){
                personaje_id.style.right = horizontal + "px"; //COLISION CONGELADOR
            }
            else if(horizontal == 260 && vertical > 120 && vertical <= 160 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 250 && vertical > 160 && vertical < 200 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 240 && vertical >= 200 && vertical < 230 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 230 && vertical >= 230 && vertical < 260 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 220 && vertical >= 260 && vertical < 280 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(horizontal == 210 && vertical >= 280 && vertical < 300 && arbol.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION ARBOL
            }
            else if(vertical < 70 && vertical >= 20 && horizontal == 370 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(vertical == 60 && horizontal == 290 && reno.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION RENO
            }
            else if(vertical >= 320 && vertical <= 350 && horizontal == 350 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical > 350 && vertical < 370 && horizontal == 340 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION REGALOS
            }
            else if(vertical > 350 && vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 100 && vertical > 320 && casa.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 100 && (vertical == 290 || vertical == 280) && casa.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION CASA
            }
            else if(horizontal == 160 && vertical > 280 && vertical < 320 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else if(horizontal == 150 && vertical >= 320 && vertical < 350 && papa_noel.style.visibility == "visible"){
                personaje_id.style.right = horizontal + "px"; //COLISION PAPA NOEL
            }
            else{
                personaje_id.style.right = (horizontal - 10) + "px";
            }
        }
        else if(key.keyCode == abajo){
            personaje_id.style.backgroundPosition = "-45px -5px";
            if(vertical == 0){
                personaje_id.style.bottom = vertical + "px"; //COLISION FINAL ABAJO
            }
            else if(vertical == 120 && horizontal < 330 && horizontal > 120 && muro_comida.style.visibility != "hidden"){
                personaje_id.style.bottom = vertical + "px"; //COLISION MURO COMIDA
            }
            else if(vertical == 80 && horizontal > 150 && valla.style.visibility == "visible"){
                personaje_id.style.bottom = vertical + "px"; //COLISION VALLA
            }
            else if(vertical == 300 && horizontal > 180 && horizontal < 210 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 280 && horizontal == 210 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 260 && horizontal == 220 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 230 && horizontal == 230 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 200 && horizontal == 240 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 170 && horizontal == 250 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 270 && horizontal == 180 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 240 && horizontal == 170 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 210 && horizontal == 160 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 190 && horizontal == 150 && arbol.style.visibility == "visible"){ //COLISION ARBOL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal <= 360 && horizontal > 330 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 60 && horizontal <= 330 && horizontal > 280 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 70 && horizontal <= 280 && horizontal > 250 && reno.style.visibility == "visible"){ //COLISION RENO
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 360 && horizontal == 280 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 350 && horizontal == 270 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 370 && horizontal == 290 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 370 && horizontal == 330 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 360 && horizontal == 340 && regalos.style.visibility == "visible"){ //COLISION REGALOS
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 350 && horizontal <= 140 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else if(vertical == 320 && horizontal == 150 && papa_noel.style.visibility == "visible"){ //COLISION PAPA NOEL
                personaje_id.style.bottom = vertical + "px";
            }
            else{
                personaje_id.style.bottom = (vertical - 10) + "px";
            }
        }
        if(vertical >= 0 && vertical <= 40 && horizontal >= 0 && horizontal <= 20){
            puerta.style.opacity = 0.5;
        }
        else{
            puerta.style.opacity = 1;
        }
        
        if(vertical <= 200 && vertical > 180 && horizontal >= 180 && horizontal <= 200 && start_on == false){
            swal('A jugar!',"Com t'hauràs fixat estàs a un mercat gegant.\n\nTindràs que ajudar a la propietària (Rosa) a donar els productes indicats als clients.\n\nElla et donarà la teva recompensa.\n\nParla amb ella i presenta't.");
            start.style.visibility = "hidden";
            start_on = true;
            audio.play();
            audio.style.visibility = "visible";
            siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "110" + "px";
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && start_on == true && primera_charla == false){
            swal('Hola!',"Rosa: Encantada, soc la propietària d'aquest mercat.\n\nNecessitaré que entreguis el producte que vol cada client.\n\nAnem a fer una prova, porta-me'n un plàtan de la parada de fruita.");
            primera_charla = true;
            siguiente_objetivo.style.backgroundImage = "url('images/platano.png')";
            siguiente_objetivo.style.width = "80" + "px";
            siguiente_objetivo.style.height = "80" + "px";
        }
        else if(vertical == 320 && horizontal == 320 && primera_charla == true && platano == false){
            swal('Has agafat un plàtan!','Porta-li a Rosa');
            platano = true;
            siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "110" + "px";
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && platano == true && platano_hecho == false){
            swal('Molt bé!',"Rosa: Ara parla amb el client 1 a veure quin producte desitga.\n\nSe t'han afegit 50 punts.",'success');
            platano_hecho = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
            siguiente_objetivo.style.backgroundImage = "url('images/cliente1.png')";
            siguiente_objetivo.style.width = "30" + "px";
            siguiente_objetivo.style.height = "60" + "px";
        }
        else if(vertical == 320 && (horizontal == 360 || horizontal == 350) && platano_hecho == true && cliente1_on == false){
            swal('Hola, com va tot?','Client 1: Jo soc en Ramón, i he vingut al mercat perque necessito 1kg de taronges.\n\nPodries ajudarme?');
            cliente1_on = true;
            siguiente_objetivo.style.backgroundImage = "url('images/naranja.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "60" + "px";
        }
        else if(horizontal == 260 && (vertical == 210 || vertical == 220) && cliente1_on == true && naranjas == false){
            swal('Has agafat 1kg de taronges','Porta el producte al client 1');
            naranjas = true;
            siguiente_objetivo.style.backgroundImage = "url('images/cliente1.png')";
            siguiente_objetivo.style.width = "30" + "px";
            siguiente_objetivo.style.height = "60" + "px";
        }
        else if(vertical == 320 && (horizontal == 360 || horizontal == 350) && naranjas == true && naranjas_hecho == false){
            naranjas_hecho = true;
            swal('Moltes gracies!','Client 1: Ara jà podré fer-me els meus sucs.\n\nFins aviat.');
            cliente1.style.visibility = "hidden";
            indicador1.style.visibility = "hidden";
            siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "110" + "px";
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && naranjas_hecho == true && cliente1_completado == false){
            swal('Ho has conseguit!',"Rosa: Ho estàs fent molt bè, però anem a veure si es suficient.\n\nBusca al client 2 a veure quin producte desitga.\n\nSe t'han afegit 50 punts.",'success');
            cliente1_completado = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
            siguiente_objetivo.style.backgroundImage = "url('images/cliente2.png')";
            siguiente_objetivo.style.width = "40" + "px";
            siguiente_objetivo.style.height = "60" + "px";
        }
        else if(vertical >= 0 && vertical <= 20 && horizontal == 190 && cliente1_completado == true && cliente2_on == false){
            swal('Hola!','Client 2: Necessito que em portis cereals.\n\nCrec que eren uns amb caixa verda.\n\nAjudam a trobarlos, siusplau.');
            cliente2_on = true;
            siguiente_objetivo.style.backgroundImage = "url('images/cereales.PNG')";
            siguiente_objetivo.style.width = "30" + "px";
            siguiente_objetivo.style.height = "50" + "px";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "45" + "%";
        }
        else if(vertical > 340 && horizontal == 150 && cliente2_on == true && cereales_on == false){
            swal('Has agafat una caixa de cereals!','Porta el producte al client 2');
            siguiente_objetivo.style.backgroundImage = "url('images/cliente2.png')";
            siguiente_objetivo.style.width = "40" + "px";
            siguiente_objetivo.style.height = "60" + "px";
            siguiente_objetivo.style.backgroundSize = "cover";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "45" + "%";
            cereales_on = true;
            valla.style.visibility = "visible";
            setTimeout(valla_on,4000);
            function valla_on(){
                swal('Oh no!','Ha aparegut una porta i no podem donar el producte al client.\n\Parla amb Rosa a veure que podem fer.','warning');
                setTimeout(llave,2000);
                function llave(){
                    llave_id.style.visibility = "visible";
                    siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
                    siguiente_objetivo.style.width = "60" + "px";
                    siguiente_objetivo.style.height = "110" + "px";
                    siguiente_objetivo.style.top = "25" + "%";
                    siguiente_objetivo.style.left = "35" + "%";
                }
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cereales_on == true && llave == false){
            swal('Que???',"Rosa: Aixó si que no m'ho ho esperava, feia molt de temps que no apareixia la porta.\n\nTinc una clau, però no se on la he posat.\n\nAjudam a buscarla rápid, només tenim 30 segons abans que el client marxi.");
            llave = true;
            cuenta_atras.style.visibility = "visible";
            siguiente_objetivo.style.backgroundImage = "url('images/llave.png')";
            siguiente_objetivo.style.width = "32" + "px";
            siguiente_objetivo.style.height = "50" + "px";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "45" + "%";
            var total = 40;
            var interval = setInterval(contador,1000);
            function contador() {
                document.getElementById('cuenta_atras').innerHTML = total;
                if(total==0){
                    cliente2.style.visibility = "hidden";
                    indicador2.style.visibility = "hidden";
                    cuenta_atras.style.visibility = "hidden";
                    clearInterval(interval);
                    cliente2_error = true;
                    setTimeout(mensaje,2000);
                    function mensaje(){
                        swal('Has fallat!','El client ha marxat.\n\nParla amb Rosa.','danger');
                        siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
                        siguiente_objetivo.style.width = "60" + "px";
                        siguiente_objetivo.style.height = "110" + "px";
                        siguiente_objetivo.style.top = "25" + "%";
                        siguiente_objetivo.style.left = "35" + "%";
                    }
                }
                else if(llave_cogida == true){
                    clearInterval(interval);
                    cuenta_atras.style.visibility = "hidden";
                }
                else{
                    total-=1;
                }
            }
        }
        else if(horizontal == 170 && vertical == 120 && llave == true && llave_cogida == false && llave_id.style.visibility != "hidden"){
            if(cliente2_error == false){
                swal('Has trobat la clau!','Porta el producte al client');
                siguiente_objetivo.style.backgroundImage = "url('images/cliente2.png')";
                siguiente_objetivo.style.width = "40" + "px";
                siguiente_objetivo.style.height = "60" + "px";
                siguiente_objetivo.style.top = "30" + "%";
                siguiente_objetivo.style.left = "45" + "%";
            }
            else{
                swal('Has trobat la clau!','Però és massa tard, el client ja ha marxat.\n\nParla amb Rosa.');
                siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
                siguiente_objetivo.style.width = "60" + "px";
                siguiente_objetivo.style.height = "110" + "px";
                siguiente_objetivo.style.top = "25" + "%";
                siguiente_objetivo.style.left = "35" + "%";
            }
            llave_cogida = true;
            llave_id.style.visibility = "hidden";
            valla.style.visibility = "hidden";
        }
        else if(vertical >= 0 && vertical <= 20 && horizontal == 190 && cliente2_error == false && llave_cogida == true && cliente2_completado == false){
            swal('Graciés!','Client 2: Has pogut obrir la porta, estava molt espantada.\n\nQue vagi bé.');
            cliente2_completado = true;
            siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "110" + "px";
            siguiente_objetivo.style.top = "25" + "%";
            siguiente_objetivo.style.left = "35" + "%";
            setTimeout(mensaje2,5000);
            function mensaje2(){
                cliente2.style.visibility = "hidden";
                indicador2.style.visibility = "hidden";
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cliente2_completado == true && cliente2_error == false && cliente3 == false){
            swal('Ho has conseguit!',"Rosa: Ho estàs fent molt bé, però anem a veure si es suficiente.\n\nBusca al client 3, no el veig per aquí, a veure que desitga.\n\nSe t'han afegit 50 punts.",'success');
            cliente3 = true;
            siguiente_objetivo.style.backgroundImage = "url('images/interrogante.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "60" + "px";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "45" + "%";
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && cliente2_error == true && cliente3 == false){
            swal('Oh no!','Rosa: El client 2 ha marxat, no et podré recompensar.\n\nIntenta que no torni a passar.\n\nBusca al client 3, no el veig per aquí, a veure que desitga.','danger');
            cliente3 = true;
            siguiente_objetivo.style.backgroundImage = "url('images/interrogante.png')";
            siguiente_objetivo.style.width = "60" + "px";
            siguiente_objetivo.style.height = "60" + "px";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "40" + "%";
            llave_id.style.visibility = "hidden";
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && cliente3 == true && cambio_fondo == false){
            cambio_fondo = true;
            nieve.style.visibility = "visible";
            indicador3.style.visibility = "visible";
            arbol.style.visibility = "visible";
            casa.style.visibility = "visible";
            papa_noel.style.visibility = "visible";
            puerta.style.visibility = "visible";
            regalos.style.visibility = "visible";
            reno.style.visibility = "visible";
            dueña.style.visibility = "hidden";
            caja.style.visibility = "hidden";
            cereales.style.visibility = "hidden";
            puesto_frutas_1.style.visibility = "hidden";
            puesto_frutas_2.style.visibility = "hidden";
            puesto_frutas_3.style.visibility = "hidden";
            puesto_frutas_4.style.visibility = "hidden";
            congelador.style.visibility = "hidden";
            muro_comida.style.visibility = "hidden";
            valla.style.visibility = "hidden";
            llave_id.style.visibility = "hidden";
            container.style.backgroundImage = "url('images/fondo_nieve.jpg')";
            nombre_dueña.style.visibility = "hidden";
        }
        else if(vertical == 280 && horizontal < 150 && horizontal >= 120 && cambio_fondo == true && papa_noel_on == false){
            swal('Hola!',"Papa Noel: Benvigut a Rovaniemi, Finlandia.\n\nImagino que t'ha enviat la Rosa. He anat a la botiga a comprar detergent però he vist que hi havia gent esperant així que li he dit a Rosa que m'ho porti.\n\nPodries anar a buscarlos?\n\nSi no estic equivocat la caixa era de color vermell.");
            papa_noel_on = true;
            siguiente_objetivo.style.backgroundImage = "url('images/detergente.PNG')";
            siguiente_objetivo.style.width = "70" + "px";
            siguiente_objetivo.style.height = "30" + "px";
            siguiente_objetivo.style.top = "30" + "%";
            siguiente_objetivo.style.left = "45" + "%";
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && papa_noel_on == true && cambio_fondo2 == false){
            cambio_fondo2 = true;
            nieve.style.visibility = "hidden";
            indicador3.style.visibility = "hidden";
            arbol.style.visibility = "hidden";
            casa.style.visibility = "hidden";
            papa_noel.style.visibility = "hidden";
            regalos.style.visibility = "hidden";
            reno.style.visibility = "hidden";
            dueña.style.visibility = "visible";
            caja.style.visibility = "visible";
            cereales.style.visibility = "visible";
            puesto_frutas_1.style.visibility = "visible";
            puesto_frutas_2.style.visibility = "visible";
            puesto_frutas_3.style.visibility = "visible";
            puesto_frutas_4.style.visibility = "visible";
            congelador.style.visibility = "visible";
            muro_comida.style.visibility = "visible";
            container.style.backgroundImage = "url('images/fondo.jpg')";
            nombre_dueña.style.visibility = "visible";

        }
        else if(vertical == 120 && horizontal < 320 && horizontal >= 260 && cambio_fondo2 == true && detergente == false){
            swal('Has agafat una caixa de detergent!','Porta-li a Papa Noel');
            detergente = true;
            siguiente_objetivo.style.backgroundImage = "url('images/papa_noel.png')";
            siguiente_objetivo.style.width = "45" + "px";
            siguiente_objetivo.style.height = "60" + "px";
        }
        else if((vertical == 0 || vertical == 10) && horizontal == 0 && detergente == true && cambio_fondo3 == false){
            cambio_fondo3 = true;
            nieve.style.visibility = "visible";
            indicador3.style.visibility = "visible";
            arbol.style.visibility = "visible";
            casa.style.visibility = "visible";
            papa_noel.style.visibility = "visible";
            puerta.style.visibility = "visible";
            regalos.style.visibility = "visible";
            reno.style.visibility = "visible";
            dueña.style.visibility = "hidden";
            caja.style.visibility = "hidden";
            cereales.style.visibility = "hidden";
            puesto_frutas_1.style.visibility = "hidden";
            puesto_frutas_2.style.visibility = "hidden";
            puesto_frutas_3.style.visibility = "hidden";
            puesto_frutas_4.style.visibility = "hidden";
            congelador.style.visibility = "hidden";
            muro_comida.style.visibility = "hidden";
            valla.style.visibility = "hidden";
            llave_id.style.visibility = "hidden";
            container.style.backgroundImage = "url('images/fondo_nieve.jpg')";
            nombre_dueña.style.visibility = "hidden";

        }
        else if(vertical == 280 && horizontal < 150 && horizontal >= 120 && cambio_fondo3 == true && papa_noel_completado == false){
            swal('Has arribat!','Papa Noel: Moltes gracies per ajudarme. Aquest nadal seré bo amb tu.\n\nHO HO HO FELIZ NAVIDAD');
            setTimeout(cambio,3000);
            function cambio(){
                papa_noel_completado = true;
                nieve.style.visibility = "hidden";
                indicador3.style.visibility = "hidden";
                arbol.style.visibility = "hidden";
                casa.style.visibility = "hidden";
                papa_noel.style.visibility = "hidden";
                regalos.style.visibility = "hidden";
                reno.style.visibility = "hidden";
                dueña.style.visibility = "visible";
                caja.style.visibility = "visible";
                cereales.style.visibility = "visible";
                puesto_frutas_1.style.visibility = "visible";
                puesto_frutas_2.style.visibility = "visible";
                puesto_frutas_3.style.visibility = "visible";
                puesto_frutas_4.style.visibility = "visible";
                congelador.style.visibility = "visible";
                muro_comida.style.visibility = "visible";
                container.style.backgroundImage = "url('images/fondo.jpg')";
                nombre_dueña.style.visibility = "visible";
                siguiente_objetivo.style.backgroundImage = "url('images/dueña.png')";
                siguiente_objetivo.style.width = "60" + "px";
                siguiente_objetivo.style.height = "110" + "px";
                siguiente_objetivo.style.top = "25" + "%";
                siguiente_objetivo.style.left = "35" + "%";
            }
        }
        else if(vertical == 270 && horizontal < 80 && horizontal > 20 && papa_noel_completado == true && juego_completado == false){
            swal('Ho has conseguit!',"Rosa: T'ho agraeixo molt, sense tu no hagues sigut possible.\n\nFins una altre.\n\nSe t'han afegit 50 punts.",'success');
            juego_completado = true;
            puntos += 50;
            document.getElementById('puntuacion').innerHTML = puntos;
        }
        else if(juego_completado == true){
            setTimeout(final,4000);
            function final(){
                indicador3.style.visibility = "hidden";
                arbol.style.visibility = "hidden";
                casa.style.visibility = "hidden";
                papa_noel.style.visibility = "hidden";
                regalos.style.visibility = "hidden";
                reno.style.visibility = "hidden";
                dueña.style.visibility = "hidden";
                caja.style.visibility = "hidden";
                cereales.style.visibility = "hidden";
                puesto_frutas_1.style.visibility = "hidden";
                puesto_frutas_2.style.visibility = "hidden";
                puesto_frutas_3.style.visibility = "hidden";
                puesto_frutas_4.style.visibility = "hidden";
                congelador.style.visibility = "hidden";
                muro_comida.style.visibility = "hidden";
                personaje_id.style.visibility = "hidden";
                puerta.style.visibility = "hidden";
                boton.style.visibility = "hidden";
                container.style.backgroundImage = "url('images/fondo_final.png')";
                nombre_dueña.style.visibility = "hidden";
                siguiente_objetivo.style.width = "0" + "px";
                siguiente_objetivo.style.height = "0" + "px";
                sumar.style.visibility = "visible";
                document.cookie=("puntuacion"+ "=" + puntos + ";" + "path=/");

            }
        }
    });
}